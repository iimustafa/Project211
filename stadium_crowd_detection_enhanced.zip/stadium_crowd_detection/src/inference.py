"""
Inference script for the stadium crowd detection model.
This script loads a trained model and performs detection and classification on images.
"""

import os
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont
from src.model import FanDetectionModel

class StadiumCrowdDetector:
    """Class for detecting and classifying fans in stadium images."""
    
    def __init__(self, model_path, input_shape=(384, 512, 3)):
        """
        Initialize the detector.
        
        Args:
            model_path: Path to the trained model
            input_shape: Input image shape (height, width, channels)
        """
        self.input_shape = input_shape
        self.model = FanDetectionModel(input_shape=input_shape)
        self.model.load_model(model_path)
        self.team_mapping = {0: 'hilal', 1: 'ittihad'}
        self.action_mapping = {0: 'sitting', 1: 'cheering', 2: 'fighting', 3: 'throwing'}
        
    def preprocess_image(self, image_path):
        """
        Preprocess an image for inference.
        
        Args:
            image_path: Path to the image file
            
        Returns:
            Preprocessed image tensor
        """
        image = tf.io.read_file(image_path)
        image = tf.image.decode_png(image, channels=3)
        image = tf.image.resize(image, (self.input_shape[0], self.input_shape[1]))
        image = tf.image.convert_image_dtype(image, tf.float32)
        return image
    
    def detect(self, image_path):
        """
        Detect and classify fans in an image.
        
        Args:
            image_path: Path to the image file
            
        Returns:
            Detections: list of dictionaries with bbox, team, action, and scores
        """
        # Preprocess the image
        image = self.preprocess_image(image_path)
        
        # Make prediction
        bbox_pred, class_pred, team_pred, action_pred = self.model.predict(image)
        
        # Process predictions
        detections = []
        for i in range(len(bbox_pred[0])):
            # Only consider detections with high confidence
            if class_pred[0][i] > 0.5:
                # Convert normalized coordinates to pixel coordinates
                ymin, xmin, ymax, xmax = bbox_pred[0][i]
                xmin = int(xmin * self.input_shape[1])
                ymin = int(ymin * self.input_shape[0])
                xmax = int(xmax * self.input_shape[1])
                ymax = int(ymax * self.input_shape[0])
                
                # Get team and action predictions
                team_idx = np.argmax(team_pred[0][i])
                action_idx = np.argmax(action_pred[0][i])
                
                detections.append({
                    'bbox': [xmin, ymin, xmax, ymax],
                    'team': self.team_mapping[team_idx],
                    'action': self.action_mapping[action_idx],
                    'class_score': float(class_pred[0][i]),
                    'team_score': float(team_pred[0][i][team_idx]),
                    'action_score': float(action_pred[0][i][action_idx])
                })
                
        return detections
    
    def visualize_detections(self, image_path, detections, output_path=None):
        """
        Visualize detections on an image.
        
        Args:
            image_path: Path to the image file
            detections: List of detection dictionaries
            output_path: Path to save the output image (optional)
            
        Returns:
            PIL Image with visualized detections
        """
        # Load the image
        image = Image.open(image_path)
        image = image.resize((self.input_shape[1], self.input_shape[0]))
        draw = ImageDraw.Draw(image)
        
        # Draw detections
        for det in detections:
            xmin, ymin, xmax, ymax = det['bbox']
            team = det['team']
            action = det['action']
            
            # Determine color based on action (red for problematic behaviors)
            color = 'red' if action in ['fighting', 'throwing'] else 'green'
            
            # Draw bounding box
            draw.rectangle([xmin, ymin, xmax, ymax], outline=color, width=2)
            
            # Draw label
            label = f"{team}/{action}"
            draw.text((xmin, ymin-15), label, fill=color)
            
        # Save the image if output path is provided
        if output_path:
            image.save(output_path)
            
        return image
    
    def detect_problematic_behavior(self, detections, team_sections=None):
        """
        Detect problematic behavior and misplaced fans.
        
        Args:
            detections: List of detection dictionaries
            team_sections: Dictionary mapping team names to their seating sections (optional)
            
        Returns:
            List of alerts with problematic detections
        """
        alerts = []
        
        # Check for problematic actions
        for i, det in enumerate(detections):
            if det['action'] in ['fighting', 'throwing']:
                alerts.append({
                    'type': 'problematic_action',
                    'action': det['action'],
                    'team': det['team'],
                    'bbox': det['bbox'],
                    'confidence': det['action_score'],
                    'detection_id': i
                })
                
        # Check for misplaced fans if team sections are provided
        if team_sections:
            for i, det in enumerate(detections):
                x_center = (det['bbox'][0] + det['bbox'][2]) / 2
                y_center = (det['bbox'][1] + det['bbox'][3]) / 2
                
                # Check if fan is in the wrong section
                for team, section in team_sections.items():
                    if det['team'] != team and self._point_in_section(x_center, y_center, section):
                        alerts.append({
                            'type': 'misplaced_fan',
                            'fan_team': det['team'],
                            'section_team': team,
                            'bbox': det['bbox'],
                            'confidence': det['team_score'],
                            'detection_id': i
                        })
                        
        return alerts
    
    def _point_in_section(self, x, y, section):
        """Check if a point is within a section."""
        x1, y1, x2, y2 = section
        return x1 <= x <= x2 and y1 <= y <= y2
    
    def generate_alert_image(self, image_path, alert, output_path=None):
        """
        Generate an image for an alert.
        
        Args:
            image_path: Path to the image file
            alert: Alert dictionary
            output_path: Path to save the output image (optional)
            
        Returns:
            PIL Image with highlighted alert
        """
        # Load the image
        image = Image.open(image_path)
        image = image.resize((self.input_shape[1], self.input_shape[0]))
        draw = ImageDraw.Draw(image)
        
        # Draw alert bounding box
        xmin, ymin, xmax, ymax = alert['bbox']
        
        # Use red for all alerts
        color = 'red'
        
        # Draw bounding box with thicker width for emphasis
        draw.rectangle([xmin, ymin, xmax, ymax], outline=color, width=3)
        
        # Draw alert type and details
        if alert['type'] == 'problematic_action':
            label = f"ALERT: {alert['action'].upper()} detected"
        else:  # misplaced_fan
            label = f"ALERT: {alert['fan_team']} fan in {alert['section_team']} section"
            
        # Draw label with background for better visibility
        text_width, text_height = draw.textsize(label)
        draw.rectangle([xmin, ymin-20, xmin+text_width, ymin], fill=color)
        draw.text((xmin, ymin-20), label, fill='white')
        
        # Save the image if output path is provided
        if output_path:
            image.save(output_path)
            
        return image
