"""
Integration of camera control with the stadium monitoring system.
This module connects the camera controller with the detection system.
"""

import os
import cv2
import numpy as np
import time
from PIL import Image
import matplotlib.pyplot as plt

from src.camera_control import CameraController
from src.system import StadiumMonitoringSystem

class CameraMonitoringSystem:
    """Enhanced monitoring system with camera control capabilities."""
    
    def __init__(self, config=None):
        """
        Initialize the camera monitoring system.
        
        Args:
            config: Configuration dictionary (optional)
        """
        # Default configuration
        self.config = {
            'model_dir': 'models',
            'input_shape': (384, 512, 3),
            'detection_threshold': 0.5,
            'alerts_dir': 'alerts',
            'camera_outputs_dir': 'camera_outputs',
            'zoom_level': 2.5,
            'scan_speed': 15,
            'scan_pattern': 'grid',
            'stadium_sections': {
                'hilal': [0, 0, 256, 384],  # Left half of stadium (x1, y1, x2, y2)
                'ittihad': [256, 0, 512, 384]  # Right half of stadium
            }
        }
        
        # Update with provided config
        if config:
            self.config.update(config)
            
        # Initialize components
        self.monitoring_system = StadiumMonitoringSystem(config=self.config)
        self.camera_controller = CameraController(output_dir=self.config['camera_outputs_dir'])
        
        # Configure camera controller
        self.camera_controller.scan_speed = self.config['scan_speed']
        self.camera_controller.scan_pattern = self.config['scan_pattern']
        
        # Initialize system state
        self.is_initialized = False
        
    def initialize(self, detector_path=None, behavior_classifier_path=None, team_detector_path=None):
        """
        Initialize the system components.
        
        Args:
            detector_path: Path to the trained detector model (optional)
            behavior_classifier_path: Path to the trained behavior classifier (optional)
            team_detector_path: Path to the trained team detector (optional)
        """
        # Initialize the monitoring system
        self.monitoring_system.initialize(
            detector_path=detector_path,
            behavior_classifier_path=behavior_classifier_path,
            team_detector_path=team_detector_path
        )
        
        self.is_initialized = True
        print("Camera monitoring system initialized successfully.")
        
    def process_image(self, image_path, output_path=None, generate_alerts=True, zoom_on_detections=True):
        """
        Process a single image with camera control.
        
        Args:
            image_path: Path to the input image
            output_path: Path to save the output image (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            zoom_on_detections: Whether to zoom in on detections
            
        Returns:
            detections: List of detections
            alerts: List of generated alerts
            crops: List of paths to cropped detection images
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        # Process the image with the monitoring system
        detections, alerts = self.monitoring_system.process_image(
            image_path,
            output_path=output_path,
            generate_alerts=generate_alerts
        )
        
        # Load the original image for camera operations
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
            
        # Create crops directory if it doesn't exist
        crops_dir = os.path.join(self.config['camera_outputs_dir'], 'crops')
        os.makedirs(crops_dir, exist_ok=True)
        
        # Process each detection with camera control
        crops = []
        for i, det in enumerate(detections):
            # Extract bounding box
            bbox = det['bbox']
            
            # Create detection info
            detection_info = {
                'type': det['action'],
                'team': det['team'],
                'confidence': det['action_score']
            }
            
            # Zoom in on the detection
            if zoom_on_detections:
                # Save a cropped image
                crop_path = self.camera_controller.save_detection_crop(
                    image, 
                    bbox, 
                    detection_info
                )
                crops.append(crop_path)
                
                # For problematic behaviors, create a zoom sequence
                if det['action'] in ['fighting', 'throwing']:
                    sequence_paths = self.camera_controller.save_detection_sequence(
                        image,
                        bbox,
                        detection_info
                    )
                    
                    # Create a GIF from the sequence
                    gif_path = os.path.join(
                        self.config['camera_outputs_dir'],
                        f"zoom_{det['action']}_{i+1}.gif"
                    )
                    self.camera_controller.create_gif_from_sequence(
                        sequence_paths,
                        gif_path
                    )
                    crops.append(gif_path)
        
        return detections, alerts, crops
    
    def process_video(self, video_path, output_path=None, generate_alerts=True, zoom_on_detections=True, frame_interval=5):
        """
        Process a video with camera control.
        
        Args:
            video_path: Path to the input video
            output_path: Path to save the output video (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            zoom_on_detections: Whether to zoom in on detections
            frame_interval: Process every Nth frame to reduce computation
            
        Returns:
            all_detections: List of detections for each processed frame
            all_alerts: List of generated alerts
            all_crops: List of paths to cropped detection images
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        # Open video
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise ValueError(f"Could not open video: {video_path}")
            
        # Get video properties
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        # Create output video writer if needed
        out = None
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
            
        # Create output directory for detection crops
        crops_dir = os.path.join(self.config['camera_outputs_dir'], 'video_crops')
        os.makedirs(crops_dir, exist_ok=True)
        
        # Process frames
        all_detections = []
        all_alerts = []
        all_crops = []
        frame_count = 0
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            # Process every Nth frame
            if frame_count % frame_interval == 0:
                # Save frame as temporary image
                temp_path = os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg')
                cv2.imwrite(temp_path, frame)
                
                # Process the frame
                detections, alerts = self.monitoring_system.process_image(
                    temp_path, 
                    output_path=None,
                    generate_alerts=generate_alerts
                )
                
                all_detections.append(detections)
                all_alerts.extend(alerts)
                
                # Process each detection with camera control
                frame_crops = []
                for i, det in enumerate(detections):
                    # Extract bounding box
                    bbox = det['bbox']
                    
                    # Create detection info
                    detection_info = {
                        'type': det['action'],
                        'team': det['team'],
                        'confidence': det['action_score'],
                        'frame': frame_count
                    }
                    
                    # Zoom in on the detection
                    if zoom_on_detections:
                        # Save a cropped image
                        crop_path = self.camera_controller.save_detection_crop(
                            frame, 
                            bbox, 
                            detection_info
                        )
                        frame_crops.append(crop_path)
                        
                        # For problematic behaviors, create a zoom sequence
                        if det['action'] in ['fighting', 'throwing']:
                            sequence_paths = self.camera_controller.save_detection_sequence(
                                frame,
                                bbox,
                                detection_info
                            )
                            
                            # Create a GIF from the sequence
                            gif_path = os.path.join(
                                crops_dir,
                                f"zoom_{det['action']}_frame{frame_count}_{i+1}.gif"
                            )
                            self.camera_controller.create_gif_from_sequence(
                                sequence_paths,
                                gif_path
                            )
                            frame_crops.append(gif_path)
                    
                    # Draw bounding box on frame
                    xmin, ymin, xmax, ymax = bbox
                    
                    # Determine color based on action
                    color = (0, 0, 255) if det['action'] in ['fighting', 'throwing'] else (0, 255, 0)
                    
                    # Draw bounding box
                    cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), color, 2)
                    
                    # Draw label
                    label = f"{det['team']}/{det['action']}"
                    cv2.putText(frame, label, (xmin, ymin-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                
                all_crops.extend(frame_crops)
                
            # Write frame to output video
            if out:
                out.write(frame)
                
            frame_count += 1
            
            # Print progress
            if frame_count % 100 == 0:
                print(f"Processed {frame_count}/{total_frames} frames ({frame_count/total_frames*100:.1f}%)")
                
        # Release resources
        cap.release()
        if out:
            out.release()
            
        # Clean up temporary files
        if os.path.exists(os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg')):
            os.remove(os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg'))
            
        return all_detections, all_alerts, all_crops
    
    def process_live_feed(self, camera_id=0, output_path=None, generate_alerts=True, zoom_on_detections=True, duration=None):
        """
        Process a live camera feed with camera control.
        
        Args:
            camera_id: Camera ID or RTSP URL
            output_path: Path to save the output video (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            zoom_on_detections: Whether to zoom in on detections
            duration: Duration to process in seconds (None for indefinite)
            
        Returns:
            all_alerts: List of generated alerts
            all_crops: List of paths to cropped detection images
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        # Open camera
        cap = cv2.VideoCapture(camera_id)
        if not cap.isOpened():
            raise ValueError(f"Could not open camera: {camera_id}")
            
        # Get video properties
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        
        # Create output video writer if needed
        out = None
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
            
        # Create output directory for detection crops
        crops_dir = os.path.join(self.config['camera_outputs_dir'], 'live_crops')
        os.makedirs(crops_dir, exist_ok=True)
        
        # Create a window for the main feed
        cv2.namedWindow('Stadium Monitoring', cv2.WINDOW_NORMAL)
        
        # Create a window for zoomed detections
        cv2.namedWindow('Detection Zoom', cv2.WINDOW_NORMAL)
        
        # Process frames
        all_alerts = []
        all_crops = []
        frame_count = 0
        start_time = time.time()
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            # Check if duration exceeded
            if duration and time.time() - start_time > duration:
                break
                
            # Process every 5th frame to reduce computation
            if frame_count % 5 == 0:
                # Save frame as temporary image
                temp_path = os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg')
                cv2.imwrite(temp_path, frame)
                
                # Process the frame
                detections, alerts = self.monitoring_system.process_image(
                    temp_path, 
                    output_path=None,
                    generate_alerts=generate_alerts
                )
                
                all_alerts.extend(alerts)
                
                # Process each detection with camera control
                frame_crops = []
                for i, det in enumerate(detections):
                    # Extract bounding box
                    bbox = det['bbox']
                    
                    # Create detection info
                    detection_info = {
                        'type': det['action'],
                        'team': det['team'],
                        'confidence': det['action_score']
                    }
                    
                    # Zoom in on the detection
                    if zoom_on_detections:
                        # Get zoomed crop
                        zoomed = self.camera_controller.zoom_to_detection(
                            frame, 
                            bbox, 
                            zoom_level=self.config['zoom_level']
                        )
                        
                        # Display the zoomed detection
                        cv2.imshow('Detection Zoom', zoomed)
                        
                        # Save a cropped image
                        crop_path = self.camera_controller.save_detection_crop(
                            frame, 
                            bbox, 
                            detection_info
                        )
                        frame_crops.append(crop_path)
                        
                        # For problematic behaviors, create a zoom sequence
                        if det['action'] in ['fighting', 'throwing']:
                            sequence_paths = self.camera_controller.save_detection_sequence(
                                frame,
                                bbox,
                                detection_info
                            )
                            
                            # Create a GIF from the sequence
                            gif_path = os.path.join(
                                crops_dir,
                                f"zoom_{det['action']}_{int(time.time())}_{i+1}.gif"
                            )
                            self.camera_controller.create_gif_from_sequence(
                                sequence_paths,
                                gif_path
                            )
                            frame_crops.append(gif_path)
                    
                    # Draw bounding box on frame
                    xmin, ymin, xmax, ymax = bbox
                    
                    # Determine color based on action
                    color = (0, 0, 255) if det['action'] in ['fighting', 'throwing'] else (0, 255, 0)
                    
                    # Draw bounding box
                    cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), color, 2)
                    
                    # Draw label
                    label = f"{det['team']}/{det['action']}"
                    cv2.putText(frame, label, (xmin, ymin-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                
                all_crops.extend(frame_crops)
                
            # Display frame
            cv2.imshow('Stadium Monitoring', frame)
            
            # Write frame to output video
            if out:
                out.write(frame)
                
            frame_count += 1
            
            # Exit on 'q' key press
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
        # Release resources
        cap.release()
        if out:
            out.release()
        cv2.destroyAllWindows()
        
        # Clean up temporary files
        if os.path.exists(os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg')):
            os.remove(os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg'))
            
        return all_alerts, all_crops
    
    def scan_and_monitor(self, image_path, output_path=None, generate_alerts=True):
        """
        Scan an image and monitor for problematic behaviors.
        
        Args:
            image_path: Path to the input image
            output_path: Path to save the output image (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            
        Returns:
            detections: List of detections
            alerts: List of generated alerts
            crops: List of paths to cropped detection images
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        # Load the image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
            
        height, width = image.shape[:2]
        
        # Create a copy for visualization
        vis_image = image.copy()
        
        # Create output directory for scanned crops
        scans_dir = os.path.join(self.config['camera_outputs_dir'], 'scans')
        os.makedirs(scans_dir, exist_ok=True)
        
        # Initialize results
        all_detections = []
        all_alerts = []
        all_crops = []
        
        # Scan the image
        scan_count = 0
        for position, cropped in self.camera_controller.scan_area(image, width, height):
            scan_count += 1
            
            # Save the cropped view
            crop_path = os.path.join(scans_dir, f"scan_{scan_count}.jpg")
            cv2.imwrite(crop_path, cropped)
            
            # Process the cropped view
            temp_path = os.path.join(self.config['camera_outputs_dir'], 'temp_scan.jpg')
            cv2.imwrite(temp_path, cropped)
            
            # Process the cropped view with the monitoring system
            try:
                detections, alerts = self.monitoring_system.process_image(
                    temp_path, 
                    output_path=None,
                    generate_alerts=generate_alerts
                )
                
                # If detections found, add to results
                if detections:
                    all_detections.extend(detections)
                    all_alerts.extend(alerts)
                    
                    # Process each detection
                    for det in detections:
                        # Adjust bounding box to original image coordinates
                        x, y = position
                        x_offset = max(0, x - width // (2 * self.camera_controller.zoom_level))
                        y_offset = max(0, y - height // (2 * self.camera_controller.zoom_level))
                        
                        bbox = det['bbox']
                        adjusted_bbox = [
                            bbox[0] + x_offset,
                            bbox[1] + y_offset,
                            bbox[2] + x_offset,
                            bbox[3] + y_offset
                        ]
                        
                        # Create detection info
                        detection_info = {
                            'type': det['action'],
                            'team': det['team'],
                            'confidence': det['action_score']
                        }
                        
                        # Save a zoomed crop
                        crop_path = self.camera_controller.save_detection_crop(
                            image, 
                            adjusted_bbox, 
                            detection_info
                        )
                        all_crops.append(crop_path)
                        
                        # Draw on visualization image
                        xmin, ymin, xmax, ymax = adjusted_bbox
                        
                        # Determine color based on action
                        color = (0, 0, 255) if det['action'] in ['fighting', 'throwing'] else (0, 255, 0)
                        
                        # Draw bounding box
                        cv2.rectangle(vis_image, (xmin, ymin), (xmax, ymax), color, 2)
                        
                        # Draw label
                        label = f"{det['team']}/{det['action']}"
                        cv2.putText(vis_image, label, (xmin, ymin-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            except Exception as e:
                print(f"Error processing scan {scan_count}: {e}")
                
        # Save the visualization image
        if output_path:
            cv2.imwrite(output_path, vis_image)
            
        # Clean up temporary files
        if os.path.exists(os.path.join(self.config['camera_outputs_dir'], 'temp_scan.jpg')):
            os.remove(os.path.join(self.config['camera_outputs_dir'], 'temp_scan.jpg'))
            
        print(f"Completed {scan_count} scans, found {len(all_detections)} detections")
        
        return all_detections, all_alerts, all_crops
    
    def generate_report(self, output_path=None):
        """
        Generate a summary report of the monitoring system.
        
        Args:
            output_path: Path to save the report (optional)
            
        Returns:
            Report text
        """
        # Generate alert report
        report = self.monitoring_system.alert_system.generate_alert_report(output_path)
        
        return report
    
    def visualize_alerts(self, output_path=None):
        """
        Visualize the distribution of alerts.
        
        Args:
            output_path: Path to save the visualization (optional)
            
        Returns:
            Matplotlib figure
        """
        # Visualize alert distribution
        fig = self.monitoring_system.alert_system.visualize_alert_distribution(output_path)
        
        return fig
