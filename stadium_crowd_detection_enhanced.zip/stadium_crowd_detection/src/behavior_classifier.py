"""
Behavior classification module for stadium crowd detection system.
This module focuses on classifying fan behaviors (sitting, cheering, fighting, throwing).
"""

import os
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, applications

class BehaviorClassifier:
    """Specialized classifier for fan behaviors in stadium images."""
    
    def __init__(self, input_shape=(128, 128, 3), num_actions=4):
        """
        Initialize the behavior classifier.
        
        Args:
            input_shape: Input image shape for cropped fan images (height, width, channels)
            num_actions: Number of action classes (sitting, cheering, fighting, throwing)
        """
        self.input_shape = input_shape
        self.num_actions = num_actions
        self.model = None
        self.action_mapping = {0: 'sitting', 1: 'cheering', 2: 'fighting', 3: 'throwing'}
        self.action_mapping_inv = {'sitting': 0, 'cheering': 1, 'fighting': 2, 'throwing': 3}
        
    def build_model(self):
        """Build the behavior classification model."""
        # Use a lightweight model for faster inference
        base_model = applications.MobileNetV2(
            input_shape=self.input_shape,
            include_top=False,
            weights='imagenet'
        )
        
        # Freeze early layers
        for layer in base_model.layers[:100]:
            layer.trainable = False
            
        # Create the classification model
        inputs = layers.Input(shape=self.input_shape)
        x = base_model(inputs)
        x = layers.GlobalAveragePooling2D()(x)
        x = layers.Dropout(0.2)(x)
        x = layers.Dense(128, activation='relu')(x)
        x = layers.Dropout(0.2)(x)
        outputs = layers.Dense(self.num_actions, activation='softmax', name='action_output')(x)
        
        self.model = models.Model(inputs=inputs, outputs=outputs)
        
        # Compile the model
        self.model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return self.model
    
    def prepare_dataset(self, dataset_dir, batch_size=32, train_ratio=0.8):
        """
        Prepare dataset for behavior classification training.
        
        Args:
            dataset_dir: Directory containing the dataset
            batch_size: Batch size for training
            train_ratio: Ratio of data to use for training
            
        Returns:
            train_dataset, val_dataset: TensorFlow datasets for training and validation
        """
        # Load annotations
        annotations_file = os.path.join(dataset_dir, 'annotations', 'labels.json')
        with open(annotations_file, 'r') as f:
            annotations = json.load(f)
            
        # Extract fan crops and their actions
        images = []
        actions = []
        
        for ann in annotations['annotations']:
            image_id = ann['image_id']
            image_file = None
            
            # Find image filename
            for img in annotations['images']:
                if img['id'] == image_id:
                    image_file = img['file_name']
                    break
                    
            if image_file:
                image_path = os.path.join(dataset_dir, 'images', image_file)
                action = ann['attributes']['action']
                action_id = self.action_mapping_inv[action]
                
                # Load and crop the image
                image = tf.io.read_file(image_path)
                image = tf.image.decode_png(image, channels=3)
                
                # Get bounding box
                x, y, w, h = ann['bbox']
                
                # Crop the fan
                crop = tf.image.crop_to_bounding_box(
                    image, 
                    tf.maximum(0, tf.cast(y, tf.int32)),
                    tf.maximum(0, tf.cast(x, tf.int32)),
                    tf.minimum(tf.cast(h, tf.int32), tf.shape(image)[0] - tf.cast(y, tf.int32)),
                    tf.minimum(tf.cast(w, tf.int32), tf.shape(image)[1] - tf.cast(x, tf.int32))
                )
                
                # Resize to input shape
                crop = tf.image.resize(crop, (self.input_shape[0], self.input_shape[1]))
                crop = tf.image.convert_image_dtype(crop, tf.float32)
                
                images.append(crop)
                actions.append(action_id)
        
        # Convert to tensors
        images = tf.stack(images)
        actions = tf.convert_to_tensor(actions)
        
        # Create dataset
        dataset = tf.data.Dataset.from_tensor_slices((images, actions))
        
        # Shuffle and split
        dataset = dataset.shuffle(buffer_size=len(images))
        train_size = int(len(images) * train_ratio)
        
        train_dataset = dataset.take(train_size).batch(batch_size).prefetch(tf.data.AUTOTUNE)
        val_dataset = dataset.skip(train_size).batch(batch_size).prefetch(tf.data.AUTOTUNE)
        
        return train_dataset, val_dataset
    
    def train(self, train_dataset, val_dataset, epochs=20, callbacks=None):
        """
        Train the behavior classification model.
        
        Args:
            train_dataset: TensorFlow dataset for training
            val_dataset: TensorFlow dataset for validation
            epochs: Number of training epochs
            callbacks: List of Keras callbacks
            
        Returns:
            Training history
        """
        if self.model is None:
            self.build_model()
            
        # Default callbacks if none provided
        if callbacks is None:
            callbacks = [
                tf.keras.callbacks.ModelCheckpoint(
                    filepath='../models/behavior_classifier.h5',
                    save_best_only=True,
                    monitor='val_accuracy'
                ),
                tf.keras.callbacks.EarlyStopping(
                    patience=5,
                    monitor='val_accuracy'
                ),
                tf.keras.callbacks.ReduceLROnPlateau(
                    factor=0.2,
                    patience=3,
                    monitor='val_accuracy'
                )
            ]
            
        history = self.model.fit(
            train_dataset,
            validation_data=val_dataset,
            epochs=epochs,
            callbacks=callbacks
        )
        
        return history
    
    def predict(self, image):
        """
        Predict the action for a fan image.
        
        Args:
            image: Input image tensor (cropped fan)
            
        Returns:
            Predicted action and confidence score
        """
        if self.model is None:
            raise ValueError("Model has not been built or loaded yet")
            
        # Ensure image has batch dimension
        if len(image.shape) == 3:
            image = tf.expand_dims(image, axis=0)
            
        # Make prediction
        predictions = self.model.predict(image)
        action_id = np.argmax(predictions[0])
        confidence = float(predictions[0][action_id])
        
        return self.action_mapping[action_id], confidence
    
    def save_model(self, filepath):
        """Save the model to disk."""
        if self.model is None:
            raise ValueError("Model has not been built or loaded yet")
            
        self.model.save(filepath)
        print(f"Behavior classifier saved to {filepath}")
        
    def load_model(self, filepath):
        """Load a saved model from disk."""
        self.model = models.load_model(filepath)
        print(f"Behavior classifier loaded from {filepath}")
        
        return self.model
    
    def evaluate_problematic_behavior(self, action, confidence):
        """
        Evaluate if an action is problematic.
        
        Args:
            action: Predicted action
            confidence: Confidence score
            
        Returns:
            is_problematic: Boolean indicating if the action is problematic
            severity: Severity score (0-1) for the problematic behavior
        """
        # Define problematic actions
        problematic_actions = ['fighting', 'throwing']
        
        is_problematic = action in problematic_actions
        severity = 0.0
        
        if is_problematic:
            # Calculate severity based on action type and confidence
            base_severity = 0.7 if action == 'fighting' else 0.6  # Fighting is more severe than throwing
            severity = base_severity * confidence
            
        return is_problematic, severity
