"""
Main integration module for the stadium crowd monitoring system.
This module integrates all components into a complete system.
"""

import os
import time
import cv2
import numpy as np
import tensorflow as tf
from PIL import Image
import matplotlib.pyplot as plt

from src.data_utils import StadiumDataset
from src.model import FanDetectionModel
from src.behavior_classifier import BehaviorClassifier
from src.team_detector import TeamAffiliationDetector
from src.alert_system import SecurityAlertSystem
from src.inference import StadiumCrowdDetector

class StadiumMonitoringSystem:
    """Integrated system for stadium crowd monitoring."""
    
    def __init__(self, config=None):
        """
        Initialize the stadium monitoring system.
        
        Args:
            config: Configuration dictionary (optional)
        """
        # Default configuration
        self.config = {
            'model_dir': 'models',
            'input_shape': (384, 512, 3),
            'detection_threshold': 0.5,
            'alerts_dir': 'alerts',
            'stadium_sections': {
                'hilal': [0, 0, 256, 384],  # Left half of stadium (x1, y1, x2, y2)
                'ittihad': [256, 0, 512, 384]  # Right half of stadium
            }
        }
        
        # Update with provided config
        if config:
            self.config.update(config)
            
        # Create model directory if it doesn't exist
        os.makedirs(self.config['model_dir'], exist_ok=True)
        
        # Initialize components
        self.detector = None
        self.behavior_classifier = None
        self.team_detector = None
        self.alert_system = SecurityAlertSystem(output_dir=self.config['alerts_dir'])
        
        # Initialize system state
        self.is_initialized = False
        
    def initialize(self, detector_path=None, behavior_classifier_path=None, team_detector_path=None):
        """
        Initialize the system components.
        
        Args:
            detector_path: Path to the trained detector model (optional)
            behavior_classifier_path: Path to the trained behavior classifier (optional)
            team_detector_path: Path to the trained team detector (optional)
        """
        # Initialize detector
        if detector_path and os.path.exists(detector_path):
            self.detector = StadiumCrowdDetector(detector_path, input_shape=self.config['input_shape'])
        else:
            print("Warning: Detector model not found. System will not be able to detect fans.")
            
        # Initialize behavior classifier
        if behavior_classifier_path and os.path.exists(behavior_classifier_path):
            self.behavior_classifier = BehaviorClassifier()
            self.behavior_classifier.load_model(behavior_classifier_path)
        else:
            print("Warning: Behavior classifier not found. Using detector's built-in classification.")
            
        # Initialize team detector
        if team_detector_path and os.path.exists(team_detector_path):
            self.team_detector = TeamAffiliationDetector()
            self.team_detector.load_model(team_detector_path)
        else:
            print("Warning: Team detector not found. Using detector's built-in classification.")
            
        self.is_initialized = True
        print("Stadium monitoring system initialized successfully.")
        
    def process_image(self, image_path, output_path=None, generate_alerts=True):
        """
        Process a single image for crowd monitoring.
        
        Args:
            image_path: Path to the input image
            output_path: Path to save the output image (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            
        Returns:
            detections: List of detections
            alerts: List of generated alerts (if generate_alerts is True)
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        if not self.detector:
            raise RuntimeError("Detector not available. Cannot process image.")
            
        # Detect fans in the image
        detections = self.detector.detect(image_path)
        
        # Process each detection
        alerts = []
        if generate_alerts:
            image = Image.open(image_path)
            image = image.resize((self.config['input_shape'][1], self.config['input_shape'][0]))
            
            for i, det in enumerate(detections):
                # Check for problematic behaviors
                if det['action'] in ['fighting', 'throwing']:
                    # Generate alert
                    alert_id = self.alert_system.generate_alert(
                        image=image,
                        detection=det,
                        alert_type=det['action'],
                        location=f"Position: ({det['bbox'][0]}, {det['bbox'][1]})",
                        confidence=det['action_score'],
                        details=f"Team: {det['team']}"
                    )
                    
                    alerts.append({
                        'alert_id': alert_id,
                        'type': det['action'],
                        'team': det['team'],
                        'location': f"({det['bbox'][0]}, {det['bbox'][1]})",
                        'confidence': det['action_score']
                    })
                    
                # Check for misplaced fans
                x_center = (det['bbox'][0] + det['bbox'][2]) / 2
                y_center = (det['bbox'][1] + det['bbox'][3]) / 2
                
                for team, section in self.config['stadium_sections'].items():
                    if det['team'] != team and self._point_in_section((x_center, y_center), section):
                        # Generate alert for misplaced fan
                        alert_id = self.alert_system.generate_alert(
                            image=image,
                            detection=det,
                            alert_type='misplaced_fan',
                            location=f"Position: ({det['bbox'][0]}, {det['bbox'][1]})",
                            confidence=det['team_score'],
                            details=f"{det['team']} fan in {team} section"
                        )
                        
                        alerts.append({
                            'alert_id': alert_id,
                            'type': 'misplaced_fan',
                            'fan_team': det['team'],
                            'section_team': team,
                            'location': f"({det['bbox'][0]}, {det['bbox'][1]})",
                            'confidence': det['team_score']
                        })
                        
        # Visualize detections
        if output_path:
            self.detector.visualize_detections(image_path, detections, output_path)
            
        return detections, alerts
    
    def process_video(self, video_path, output_path=None, generate_alerts=True, frame_interval=5):
        """
        Process a video for crowd monitoring.
        
        Args:
            video_path: Path to the input video
            output_path: Path to save the output video (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            frame_interval: Process every Nth frame to reduce computation
            
        Returns:
            all_detections: List of detections for each processed frame
            all_alerts: List of generated alerts
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        if not self.detector:
            raise RuntimeError("Detector not available. Cannot process video.")
            
        # Open video
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise ValueError(f"Could not open video: {video_path}")
            
        # Get video properties
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        # Create output video writer if needed
        out = None
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
            
        # Process frames
        all_detections = []
        all_alerts = []
        frame_count = 0
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            # Process every Nth frame
            if frame_count % frame_interval == 0:
                # Save frame as temporary image
                temp_path = os.path.join(self.config['alerts_dir'], 'temp_frame.jpg')
                cv2.imwrite(temp_path, frame)
                
                # Process the frame
                detections, alerts = self.process_image(
                    temp_path, 
                    output_path=None,
                    generate_alerts=generate_alerts
                )
                
                all_detections.append(detections)
                all_alerts.extend(alerts)
                
                # Draw detections on frame
                for det in detections:
                    xmin, ymin, xmax, ymax = det['bbox']
                    
                    # Determine color based on action
                    color = (0, 0, 255) if det['action'] in ['fighting', 'throwing'] else (0, 255, 0)
                    
                    # Draw bounding box
                    cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), color, 2)
                    
                    # Draw label
                    label = f"{det['team']}/{det['action']}"
                    cv2.putText(frame, label, (xmin, ymin-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                    
            # Write frame to output video
            if out:
                out.write(frame)
                
            frame_count += 1
            
            # Print progress
            if frame_count % 100 == 0:
                print(f"Processed {frame_count}/{total_frames} frames ({frame_count/total_frames*100:.1f}%)")
                
        # Release resources
        cap.release()
        if out:
            out.release()
            
        # Clean up temporary files
        if os.path.exists(os.path.join(self.config['alerts_dir'], 'temp_frame.jpg')):
            os.remove(os.path.join(self.config['alerts_dir'], 'temp_frame.jpg'))
            
        return all_detections, all_alerts
    
    def process_live_feed(self, camera_id=0, output_path=None, generate_alerts=True, duration=None):
        """
        Process a live camera feed for crowd monitoring.
        
        Args:
            camera_id: Camera ID or RTSP URL
            output_path: Path to save the output video (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            duration: Duration to process in seconds (None for indefinite)
            
        Returns:
            all_alerts: List of generated alerts
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        if not self.detector:
            raise RuntimeError("Detector not available. Cannot process live feed.")
            
        # Open camera
        cap = cv2.VideoCapture(camera_id)
        if not cap.isOpened():
            raise ValueError(f"Could not open camera: {camera_id}")
            
        # Get video properties
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        
        # Create output video writer if needed
        out = None
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
            
        # Process frames
        all_alerts = []
        frame_count = 0
        start_time = time.time()
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            # Check if duration exceeded
            if duration and time.time() - start_time > duration:
                break
                
            # Process every 5th frame to reduce computation
            if frame_count % 5 == 0:
                # Save frame as temporary image
                temp_path = os.path.join(self.config['alerts_dir'], 'temp_frame.jpg')
                cv2.imwrite(temp_path, frame)
                
                # Process the frame
                detections, alerts = self.process_image(
                    temp_path, 
                    output_path=None,
                    generate_alerts=generate_alerts
                )
                
                all_alerts.extend(alerts)
                
                # Draw detections on frame
                for det in detections:
                    xmin, ymin, xmax, ymax = det['bbox']
                    
                    # Determine color based on action
                    color = (0, 0, 255) if det['action'] in ['fighting', 'throwing'] else (0, 255, 0)
                    
                    # Draw bounding box
                    cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), color, 2)
                    
                    # Draw label
                    label = f"{det['team']}/{det['action']}"
                    cv2.putText(frame, label, (xmin, ymin-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                    
            # Display frame
            cv2.imshow('Stadium Monitoring', frame)
            
            # Write frame to output video
            if out:
                out.write(frame)
                
            frame_count += 1
            
            # Exit on 'q' key press
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
        # Release resources
        cap.release()
        if out:
            out.release()
        cv2.destroyAllWindows()
        
        # Clean up temporary files
        if os.path.exists(os.path.join(self.config['alerts_dir'], 'temp_frame.jpg')):
            os.remove(os.path.join(self.config['alerts_dir'], 'temp_frame.jpg'))
            
        return all_alerts
    
    def generate_report(self, output_path=None):
        """
        Generate a summary report of the monitoring system.
        
        Args:
            output_path: Path to save the report (optional)
            
        Returns:
            Report text
        """
        # Generate alert report
        report = self.alert_system.generate_alert_report(output_path)
        
        return report
    
    def visualize_alerts(self, output_path=None):
        """
        Visualize the distribution of alerts.
        
        Args:
            output_path: Path to save the visualization (optional)
            
        Returns:
            Matplotlib figure
        """
        # Visualize alert distribution
        fig = self.alert_system.visualize_alert_distribution(output_path)
        
        return fig
    
    def _point_in_section(self, point, section):
        """Check if a point is within a section."""
        x, y = point
        x1, y1, x2, y2 = section
        return x1 <= x <= x2 and y1 <= y <= y2
