"""
Model for stadium crowd detection and behavior classification.
This module implements the object detection model for identifying fans and classifying their behavior.
"""

import tensorflow as tf
from tensorflow.keras import layers, models, applications

class FanDetectionModel:
    """Model for detecting fans in stadium images."""
    
    def __init__(self, input_shape=(384, 512, 3), num_classes=1, num_teams=2, num_actions=4):
        """
        Initialize the fan detection model.
        
        Args:
            input_shape: Input image shape (height, width, channels)
            num_classes: Number of object classes (just 'fan' in this case)
            num_teams: Number of team classes (hilal, ittihad)
            num_actions: Number of action classes (sitting, cheering, fighting, throwing)
        """
        self.input_shape = input_shape
        self.num_classes = num_classes
        self.num_teams = num_teams
        self.num_actions = num_actions
        self.model = None
        
    def build_model(self):
        """Build the detection and classification model."""
        # Use a pre-trained model as the backbone
        base_model = applications.MobileNetV2(
            input_shape=self.input_shape,
            include_top=False,
            weights='imagenet'
        )
        
        # Freeze the base model layers
        base_model.trainable = False
        
        # Create the detection and classification heads
        inputs = layers.Input(shape=self.input_shape)
        x = base_model(inputs)
        
        # Detection head
        detection_head = layers.Conv2D(256, 3, padding='same', activation='relu')(x)
        detection_head = layers.Conv2D(128, 3, padding='same', activation='relu')(detection_head)
        detection_head = layers.GlobalAveragePooling2D()(detection_head)
        detection_head = layers.Dense(128, activation='relu')(detection_head)
        
        # Bounding box regression
        bbox_output = layers.Dense(4, name='bbox_output')(detection_head)
        
        # Classification head
        class_output = layers.Dense(self.num_classes, activation='sigmoid', name='class_output')(detection_head)
        
        # Team classification head
        team_head = layers.Dense(64, activation='relu')(detection_head)
        team_output = layers.Dense(self.num_teams, activation='softmax', name='team_output')(team_head)
        
        # Action classification head
        action_head = layers.Dense(64, activation='relu')(detection_head)
        action_output = layers.Dense(self.num_actions, activation='softmax', name='action_output')(action_head)
        
        # Create the model
        self.model = models.Model(
            inputs=inputs,
            outputs=[bbox_output, class_output, team_output, action_output]
        )
        
        # Compile the model
        self.model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
            loss={
                'bbox_output': 'mse',
                'class_output': 'binary_crossentropy',
                'team_output': 'sparse_categorical_crossentropy',
                'action_output': 'sparse_categorical_crossentropy'
            },
            loss_weights={
                'bbox_output': 1.0,
                'class_output': 1.0,
                'team_output': 0.5,
                'action_output': 0.5
            },
            metrics={
                'class_output': 'accuracy',
                'team_output': 'accuracy',
                'action_output': 'accuracy'
            }
        )
        
        return self.model
    
    def train(self, train_dataset, val_dataset, epochs=10, callbacks=None):
        """
        Train the model.
        
        Args:
            train_dataset: TensorFlow dataset for training
            val_dataset: TensorFlow dataset for validation
            epochs: Number of training epochs
            callbacks: List of Keras callbacks
            
        Returns:
            Training history
        """
        if self.model is None:
            self.build_model()
            
        # Default callbacks if none provided
        if callbacks is None:
            callbacks = [
                tf.keras.callbacks.ModelCheckpoint(
                    filepath='../models/fan_detection_model.h5',
                    save_best_only=True,
                    monitor='val_loss'
                ),
                tf.keras.callbacks.EarlyStopping(
                    patience=5,
                    monitor='val_loss'
                ),
                tf.keras.callbacks.ReduceLROnPlateau(
                    factor=0.2,
                    patience=3,
                    monitor='val_loss'
                )
            ]
            
        history = self.model.fit(
            train_dataset,
            validation_data=val_dataset,
            epochs=epochs,
            callbacks=callbacks
        )
        
        return history
    
    def predict(self, image):
        """
        Make predictions on a single image.
        
        Args:
            image: Input image tensor
            
        Returns:
            Bounding boxes, class scores, team predictions, action predictions
        """
        if self.model is None:
            raise ValueError("Model has not been built or loaded yet")
            
        # Ensure image has batch dimension
        if len(image.shape) == 3:
            image = tf.expand_dims(image, axis=0)
            
        # Make prediction
        bbox_pred, class_pred, team_pred, action_pred = self.model.predict(image)
        
        return bbox_pred, class_pred, team_pred, action_pred
    
    def save_model(self, filepath):
        """Save the model to disk."""
        if self.model is None:
            raise ValueError("Model has not been built or loaded yet")
            
        self.model.save(filepath)
        print(f"Model saved to {filepath}")
        
    def load_model(self, filepath):
        """Load a saved model from disk."""
        self.model = models.load_model(filepath)
        print(f"Model loaded from {filepath}")
        
        return self.model
