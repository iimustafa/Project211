"""
Data utilities for stadium crowd detection system.
This module handles loading and preprocessing the synthetic dataset.
"""

import os
import json
import numpy as np
from PIL import Image
import tensorflow as tf
import matplotlib.pyplot as plt

class StadiumDataset:
    """Class to handle the stadium crowd dataset."""
    
    def __init__(self, dataset_dir, image_size=(512, 384)):
        """
        Initialize the dataset handler.
        
        Args:
            dataset_dir: Directory containing the dataset
            image_size: Target image size (width, height)
        """
        self.dataset_dir = dataset_dir
        self.image_size = image_size
        self.images_dir = os.path.join(dataset_dir, 'images')
        self.annotations_file = os.path.join(dataset_dir, 'annotations', 'labels.json')
        self.annotations = None
        self.image_ids = []
        self.team_mapping = {'hilal': 0, 'ittihad': 1}
        self.action_mapping = {'sitting': 0, 'cheering': 1, 'fighting': 2, 'throwing': 3}
        
    def load_annotations(self):
        """Load annotations from JSON file."""
        if not os.path.exists(self.annotations_file):
            raise FileNotFoundError(f"Annotations file not found: {self.annotations_file}")
            
        with open(self.annotations_file, 'r') as f:
            self.annotations = json.load(f)
            
        # Extract image IDs
        self.image_ids = [img['id'] for img in self.annotations['images']]
        print(f"Loaded {len(self.image_ids)} images and {len(self.annotations['annotations'])} annotations")
        
    def get_image_path(self, image_id):
        """Get the file path for an image by ID."""
        for img in self.annotations['images']:
            if img['id'] == image_id:
                return os.path.join(self.images_dir, img['file_name'])
        return None
    
    def get_annotations_for_image(self, image_id):
        """Get all annotations for a specific image."""
        return [ann for ann in self.annotations['annotations'] if ann['image_id'] == image_id]
    
    def visualize_sample(self, image_id=None, figsize=(10, 8)):
        """Visualize a sample image with bounding boxes and labels."""
        if self.annotations is None:
            self.load_annotations()
            
        if image_id is None:
            # Pick a random image
            image_id = np.random.choice(self.image_ids)
            
        image_path = self.get_image_path(image_id)
        if image_path is None:
            print(f"Image ID {image_id} not found")
            return
            
        image = Image.open(image_path)
        anns = self.get_annotations_for_image(image_id)
        
        plt.figure(figsize=figsize)
        plt.imshow(image)
        ax = plt.gca()
        
        for ann in anns:
            x, y, w, h = ann['bbox']
            team = ann['attributes']['team']
            action = ann['attributes']['action']
            
            # Draw bounding box
            rect = plt.Rectangle((x, y), w, h, fill=False, 
                                edgecolor='red' if action in ['fighting', 'throwing'] else 'green', 
                                linewidth=2)
            ax.add_patch(rect)
            
            # Add label
            plt.text(x, y-5, f"{team}/{action}", 
                    color='white', backgroundcolor='blue' if team == 'hilal' else 'orange',
                    fontsize=8, weight='bold')
            
        plt.title(f"Image ID: {image_id}")
        plt.axis('off')
        plt.tight_layout()
        plt.show()
        
    def prepare_detection_dataset(self, train_ratio=0.8, batch_size=8):
        """
        Prepare TensorFlow dataset for object detection.
        
        Args:
            train_ratio: Ratio of data to use for training
            batch_size: Batch size for training
            
        Returns:
            train_dataset, val_dataset: TensorFlow datasets for training and validation
        """
        if self.annotations is None:
            self.load_annotations()
            
        # Split image IDs into train and validation sets
        np.random.shuffle(self.image_ids)
        split_idx = int(len(self.image_ids) * train_ratio)
        train_ids = self.image_ids[:split_idx]
        val_ids = self.image_ids[split_idx:]
        
        print(f"Training on {len(train_ids)} images, validating on {len(val_ids)} images")
        
        # Create TensorFlow datasets
        train_dataset = tf.data.Dataset.from_tensor_slices(train_ids)
        train_dataset = train_dataset.map(self._process_image_for_detection, 
                                         num_parallel_calls=tf.data.AUTOTUNE)
        train_dataset = train_dataset.batch(batch_size).prefetch(tf.data.AUTOTUNE)
        
        val_dataset = tf.data.Dataset.from_tensor_slices(val_ids)
        val_dataset = val_dataset.map(self._process_image_for_detection, 
                                     num_parallel_calls=tf.data.AUTOTUNE)
        val_dataset = val_dataset.batch(batch_size).prefetch(tf.data.AUTOTUNE)
        
        return train_dataset, val_dataset
    
    def _process_image_for_detection(self, image_id):
        """Process a single image and its annotations for object detection."""
        image_id = image_id.numpy()
        image_path = self.get_image_path(image_id)
        image = tf.io.read_file(image_path)
        image = tf.image.decode_png(image, channels=3)
        image = tf.image.convert_image_dtype(image, tf.float32)
        
        # Get annotations for this image
        anns = self.get_annotations_for_image(image_id)
        
        # Prepare bounding boxes, classes, and attributes
        boxes = []
        classes = []
        teams = []
        actions = []
        
        for ann in anns:
            x, y, w, h = ann['bbox']
            
            # Convert to normalized coordinates [ymin, xmin, ymax, xmax]
            ymin = y / self.image_size[1]
            xmin = x / self.image_size[0]
            ymax = (y + h) / self.image_size[1]
            xmax = (x + w) / self.image_size[0]
            
            boxes.append([ymin, xmin, ymax, xmax])
            classes.append(1)  # Only one class: 'fan'
            teams.append(self.team_mapping[ann['attributes']['team']])
            actions.append(self.action_mapping[ann['attributes']['action']])
        
        # Convert to tensors
        boxes = tf.convert_to_tensor(boxes, dtype=tf.float32)
        classes = tf.convert_to_tensor(classes, dtype=tf.int32)
        teams = tf.convert_to_tensor(teams, dtype=tf.int32)
        actions = tf.convert_to_tensor(actions, dtype=tf.int32)
        
        return {
            'image': image,
            'boxes': boxes,
            'classes': classes,
            'teams': teams,
            'actions': actions,
            'image_id': image_id
        }
