"""
Alert system for stadium security personnel.
This module handles generating and sending alerts for problematic behaviors and misplaced fans.
"""

import os
import time
import json
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import tensorflow as tf
import matplotlib.pyplot as plt

class SecurityAlertSystem:
    """System for generating security alerts in stadium environments."""
    
    def __init__(self, output_dir='alerts'):
        """
        Initialize the alert system.
        
        Args:
            output_dir: Directory to save alert images and data
        """
        self.output_dir = output_dir
        self.alerts_log = []
        self.alert_count = 0
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'images'), exist_ok=True)
        
    def generate_alert(self, image, detection, alert_type, location=None, confidence=None, details=None):
        """
        Generate a security alert.
        
        Args:
            image: Original image (PIL Image or path)
            detection: Detection information (bounding box, etc.)
            alert_type: Type of alert ('fighting', 'throwing', 'misplaced_fan')
            location: Location information (section, seat, etc.)
            confidence: Confidence score of the detection
            details: Additional details about the alert
            
        Returns:
            alert_id: Unique identifier for the alert
        """
        # Generate alert ID
        self.alert_count += 1
        alert_id = f"ALERT_{int(time.time())}_{self.alert_count}"
        
        # Load image if path is provided
        if isinstance(image, str):
            img = Image.open(image)
        else:
            img = image
            
        # Create alert image
        alert_image = self._create_alert_image(img, detection, alert_type, details)
        
        # Save alert image
        image_path = os.path.join(self.output_dir, 'images', f"{alert_id}.png")
        alert_image.save(image_path)
        
        # Create alert data
        alert_data = {
            'alert_id': alert_id,
            'timestamp': time.time(),
            'alert_type': alert_type,
            'location': location,
            'confidence': confidence,
            'details': details,
            'image_path': image_path,
            'bbox': detection['bbox'] if isinstance(detection, dict) and 'bbox' in detection else detection
        }
        
        # Add to alerts log
        self.alerts_log.append(alert_data)
        
        # Save updated alerts log
        self._save_alerts_log()
        
        return alert_id
    
    def _create_alert_image(self, image, detection, alert_type, details=None):
        """Create an annotated image for the alert."""
        # Create a copy of the image
        alert_image = image.copy()
        draw = ImageDraw.Draw(alert_image)
        
        # Get bounding box
        if isinstance(detection, dict) and 'bbox' in detection:
            bbox = detection['bbox']
        else:
            bbox = detection
            
        # Draw bounding box
        draw.rectangle(bbox, outline='red', width=3)
        
        # Add alert text
        alert_text = f"ALERT: {alert_type.upper()}"
        if details:
            alert_text += f" - {details}"
            
        # Draw text with background for visibility
        text_position = (bbox[0], bbox[1] - 20)
        text_background = (bbox[0], bbox[1] - 20, bbox[0] + len(alert_text) * 7, bbox[1])
        draw.rectangle(text_background, fill='red')
        draw.text(text_position, alert_text, fill='white')
        
        return alert_image
    
    def _save_alerts_log(self):
        """Save the alerts log to a JSON file."""
        log_path = os.path.join(self.output_dir, 'alerts_log.json')
        with open(log_path, 'w') as f:
            json.dump(self.alerts_log, f, indent=2)
            
    def load_alerts_log(self):
        """Load the alerts log from a JSON file."""
        log_path = os.path.join(self.output_dir, 'alerts_log.json')
        if os.path.exists(log_path):
            with open(log_path, 'r') as f:
                self.alerts_log = json.load(f)
                self.alert_count = len(self.alerts_log)
                
    def get_recent_alerts(self, count=10):
        """Get the most recent alerts."""
        return sorted(self.alerts_log, key=lambda x: x['timestamp'], reverse=True)[:count]
    
    def get_alerts_by_type(self, alert_type):
        """Get alerts of a specific type."""
        return [alert for alert in self.alerts_log if alert['alert_type'] == alert_type]
    
    def get_alert_by_id(self, alert_id):
        """Get an alert by its ID."""
        for alert in self.alerts_log:
            if alert['alert_id'] == alert_id:
                return alert
        return None
    
    def generate_alert_report(self, output_path=None):
        """
        Generate a summary report of all alerts.
        
        Args:
            output_path: Path to save the report (optional)
            
        Returns:
            Report text
        """
        if not self.alerts_log:
            report = "No alerts have been generated."
            return report
            
        # Count alerts by type
        alert_types = {}
        for alert in self.alerts_log:
            alert_type = alert['alert_type']
            if alert_type in alert_types:
                alert_types[alert_type] += 1
            else:
                alert_types[alert_type] = 1
                
        # Generate report
        report = "STADIUM SECURITY ALERT REPORT\n"
        report += "=" * 30 + "\n\n"
        report += f"Total Alerts: {len(self.alerts_log)}\n"
        report += "Alert Types:\n"
        
        for alert_type, count in alert_types.items():
            report += f"  - {alert_type}: {count}\n"
            
        report += "\nMost Recent Alerts:\n"
        recent_alerts = self.get_recent_alerts(5)
        
        for i, alert in enumerate(recent_alerts):
            timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(alert['timestamp']))
            report += f"{i+1}. [{timestamp}] {alert['alert_type'].upper()}"
            if alert['location']:
                report += f" at {alert['location']}"
            report += "\n"
            
        # Save report if output path is provided
        if output_path:
            with open(output_path, 'w') as f:
                f.write(report)
                
        return report
    
    def visualize_alert_distribution(self, output_path=None):
        """
        Visualize the distribution of alerts by type.
        
        Args:
            output_path: Path to save the visualization (optional)
            
        Returns:
            Matplotlib figure
        """
        if not self.alerts_log:
            print("No alerts to visualize.")
            return None
            
        # Count alerts by type
        alert_types = {}
        for alert in self.alerts_log:
            alert_type = alert['alert_type']
            if alert_type in alert_types:
                alert_types[alert_type] += 1
            else:
                alert_types[alert_type] = 1
                
        # Create visualization
        fig, ax = plt.subplots(figsize=(10, 6))
        
        types = list(alert_types.keys())
        counts = list(alert_types.values())
        
        # Bar chart
        bars = ax.bar(types, counts, color=['red' if t in ['fighting', 'throwing'] else 'orange' for t in types])
        
        # Add labels and title
        ax.set_xlabel('Alert Type')
        ax.set_ylabel('Count')
        ax.set_title('Distribution of Security Alerts by Type')
        
        # Add count labels on top of bars
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                   f'{int(height)}', ha='center', va='bottom')
            
        plt.tight_layout()
        
        # Save figure if output path is provided
        if output_path:
            plt.savefig(output_path)
            
        return fig
