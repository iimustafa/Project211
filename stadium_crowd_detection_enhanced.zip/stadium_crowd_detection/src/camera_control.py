"""
Camera control module for stadium crowd monitoring system.
This module handles camera movement, zooming, and cropping functionality.
"""

import os
import cv2
import numpy as np
import time
from PIL import Image

class CameraController:
    """Controller for camera movement, zooming, and cropping."""
    
    def __init__(self, output_dir='camera_outputs'):
        """
        Initialize the camera controller.
        
        Args:
            output_dir: Directory to save camera outputs
        """
        self.output_dir = output_dir
        self.current_position = (0, 0)  # (x, y) position in the scene
        self.zoom_level = 1.0  # 1.0 means no zoom
        self.scan_speed = 10  # pixels per step
        self.scan_pattern = 'horizontal'  # 'horizontal', 'vertical', 'grid'
        self.crop_count = 0
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
    def move_camera(self, direction, distance=None):
        """
        Move the camera in the specified direction.
        
        Args:
            direction: Direction to move ('left', 'right', 'up', 'down')
            distance: Distance to move in pixels (default: scan_speed)
            
        Returns:
            New camera position (x, y)
        """
        if distance is None:
            distance = self.scan_speed
            
        x, y = self.current_position
        
        if direction == 'left':
            x -= distance
        elif direction == 'right':
            x += distance
        elif direction == 'up':
            y -= distance
        elif direction == 'down':
            y += distance
            
        self.current_position = (x, y)
        return self.current_position
    
    def set_position(self, position):
        """
        Set the camera position directly.
        
        Args:
            position: (x, y) position
            
        Returns:
            New camera position (x, y)
        """
        self.current_position = position
        return self.current_position
    
    def zoom(self, level):
        """
        Set the zoom level.
        
        Args:
            level: Zoom level (1.0 = no zoom, 2.0 = 2x zoom, etc.)
            
        Returns:
            New zoom level
        """
        self.zoom_level = max(1.0, level)
        return self.zoom_level
    
    def scan_area(self, frame, width, height, pattern=None):
        """
        Scan the area according to the specified pattern.
        
        Args:
            frame: Input frame
            width: Width of the frame
            height: Height of the frame
            pattern: Scan pattern (default: self.scan_pattern)
            
        Returns:
            Generator yielding (position, cropped_frame) tuples
        """
        if pattern is None:
            pattern = self.scan_pattern
            
        if pattern == 'horizontal':
            # Scan horizontally, row by row
            for y in range(0, height, self.scan_speed):
                for x in range(0, width, self.scan_speed):
                    self.current_position = (x, y)
                    cropped = self.get_current_view(frame)
                    yield (self.current_position, cropped)
                    
        elif pattern == 'vertical':
            # Scan vertically, column by column
            for x in range(0, width, self.scan_speed):
                for y in range(0, height, self.scan_speed):
                    self.current_position = (x, y)
                    cropped = self.get_current_view(frame)
                    yield (self.current_position, cropped)
                    
        elif pattern == 'grid':
            # Scan in a grid pattern
            grid_size = int(self.scan_speed * 5)
            for y in range(0, height, grid_size):
                for x in range(0, width, grid_size):
                    self.current_position = (x, y)
                    cropped = self.get_current_view(frame)
                    yield (self.current_position, cropped)
    
    def get_current_view(self, frame):
        """
        Get the current view based on position and zoom level.
        
        Args:
            frame: Input frame
            
        Returns:
            Cropped and zoomed frame
        """
        height, width = frame.shape[:2]
        x, y = self.current_position
        
        # Calculate view size based on zoom
        view_width = int(width / self.zoom_level)
        view_height = int(height / self.zoom_level)
        
        # Calculate view boundaries
        x1 = max(0, min(x - view_width // 2, width - view_width))
        y1 = max(0, min(y - view_height // 2, height - view_height))
        x2 = min(width, x1 + view_width)
        y2 = min(height, y1 + view_height)
        
        # Crop the frame
        cropped = frame[y1:y2, x1:x2]
        
        return cropped
    
    def zoom_to_detection(self, frame, bbox, padding=20, zoom_level=2.0):
        """
        Zoom to a detected object.
        
        Args:
            frame: Input frame
            bbox: Bounding box [x, y, width, height] or [x1, y1, x2, y2]
            padding: Padding around the bounding box
            zoom_level: Zoom level to apply
            
        Returns:
            Cropped frame showing the detection
        """
        # Convert bbox format if needed
        if len(bbox) == 4:
            if bbox[2] < bbox[0] or bbox[3] < bbox[1]:
                # Format is [x, y, width, height]
                x1, y1, w, h = bbox
                x2, y2 = x1 + w, y1 + h
            else:
                # Format is [x1, y1, x2, y2]
                x1, y1, x2, y2 = bbox
        
        # Add padding
        height, width = frame.shape[:2]
        x1 = max(0, x1 - padding)
        y1 = max(0, y1 - padding)
        x2 = min(width, x2 + padding)
        y2 = min(height, y2 + padding)
        
        # Set position to center of detection
        center_x = (x1 + x2) // 2
        center_y = (y1 + y2) // 2
        self.set_position((center_x, center_y))
        
        # Set zoom level
        self.zoom(zoom_level)
        
        # Get the zoomed view
        zoomed = self.get_current_view(frame)
        
        return zoomed
    
    def save_detection_crop(self, frame, bbox, detection_info=None):
        """
        Save a cropped image of a detection.
        
        Args:
            frame: Input frame
            bbox: Bounding box [x, y, width, height] or [x1, y1, x2, y2]
            detection_info: Additional information about the detection
            
        Returns:
            Path to the saved crop
        """
        # Zoom to the detection
        cropped = self.zoom_to_detection(frame, bbox)
        
        # Create filename
        self.crop_count += 1
        timestamp = int(time.time())
        if detection_info and 'type' in detection_info:
            filename = f"detection_{detection_info['type']}_{timestamp}_{self.crop_count}.jpg"
        else:
            filename = f"detection_{timestamp}_{self.crop_count}.jpg"
            
        # Save the crop
        output_path = os.path.join(self.output_dir, filename)
        cv2.imwrite(output_path, cropped)
        
        return output_path
    
    def create_detection_sequence(self, frame, bbox, num_frames=5, zoom_start=1.0, zoom_end=3.0):
        """
        Create a sequence of frames zooming in on a detection.
        
        Args:
            frame: Input frame
            bbox: Bounding box [x, y, width, height] or [x1, y1, x2, y2]
            num_frames: Number of frames in the sequence
            zoom_start: Starting zoom level
            zoom_end: Ending zoom level
            
        Returns:
            List of frames showing progressive zoom
        """
        # Convert bbox format if needed
        if len(bbox) == 4:
            if bbox[2] < bbox[0] or bbox[3] < bbox[1]:
                # Format is [x, y, width, height]
                x1, y1, w, h = bbox
                x2, y2 = x1 + w, y1 + h
            else:
                # Format is [x1, y1, x2, y2]
                x1, y1, x2, y2 = bbox
        
        # Set position to center of detection
        center_x = (x1 + x2) // 2
        center_y = (y1 + y2) // 2
        self.set_position((center_x, center_y))
        
        # Create sequence of frames with increasing zoom
        sequence = []
        for i in range(num_frames):
            # Calculate zoom level for this frame
            zoom = zoom_start + (zoom_end - zoom_start) * i / (num_frames - 1)
            self.zoom(zoom)
            
            # Get the zoomed view
            zoomed = self.get_current_view(frame)
            sequence.append(zoomed)
            
        return sequence
    
    def save_detection_sequence(self, frame, bbox, detection_info=None):
        """
        Save a sequence of frames zooming in on a detection.
        
        Args:
            frame: Input frame
            bbox: Bounding box [x, y, width, height] or [x1, y1, x2, y2]
            detection_info: Additional information about the detection
            
        Returns:
            List of paths to the saved frames
        """
        # Create the sequence
        sequence = self.create_detection_sequence(frame, bbox)
        
        # Create base filename
        self.crop_count += 1
        timestamp = int(time.time())
        if detection_info and 'type' in detection_info:
            base_filename = f"sequence_{detection_info['type']}_{timestamp}_{self.crop_count}"
        else:
            base_filename = f"sequence_{timestamp}_{self.crop_count}"
            
        # Save each frame
        output_paths = []
        for i, frame in enumerate(sequence):
            filename = f"{base_filename}_{i+1}.jpg"
            output_path = os.path.join(self.output_dir, filename)
            cv2.imwrite(output_path, frame)
            output_paths.append(output_path)
            
        return output_paths
    
    def create_gif_from_sequence(self, sequence, output_path, duration=200):
        """
        Create a GIF from a sequence of frames.
        
        Args:
            sequence: List of frames or paths to frames
            output_path: Path to save the GIF
            duration: Duration of each frame in milliseconds
            
        Returns:
            Path to the saved GIF
        """
        # Convert frames to PIL Images if they're not already
        images = []
        for frame in sequence:
            if isinstance(frame, str):
                # Frame is a path
                img = Image.open(frame)
            else:
                # Frame is a numpy array
                img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            images.append(img)
            
        # Save as GIF
        images[0].save(
            output_path,
            save_all=True,
            append_images=images[1:],
            duration=duration,
            loop=0
        )
        
        return output_path
