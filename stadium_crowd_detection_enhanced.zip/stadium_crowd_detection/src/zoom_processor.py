"""
Enhanced zoom and crop functionality for stadium monitoring system.
This module provides specialized functions for zooming, cropping, and creating visual sequences.
"""

import os
import cv2
import numpy as np
import time
from PIL import Image
import matplotlib.pyplot as plt
import imageio

class ZoomProcessor:
    """Specialized processor for zoom and crop operations."""
    
    def __init__(self, output_dir='zoom_crops'):
        """
        Initialize the zoom processor.
        
        Args:
            output_dir: Directory to save zoom outputs
        """
        self.output_dir = output_dir
        self.crop_count = 0
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'sequences'), exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'gifs'), exist_ok=True)
        
    def crop_detection(self, image, bbox, padding=10):
        """
        Crop a detection from an image.
        
        Args:
            image: Input image (numpy array)
            bbox: Bounding box [x1, y1, x2, y2] or [x, y, w, h]
            padding: Padding around the bounding box
            
        Returns:
            Cropped image
        """
        # Convert bbox format if needed
        if len(bbox) == 4:
            if bbox[2] < bbox[0] or bbox[3] < bbox[1]:
                # Format is [x, y, width, height]
                x1, y1, w, h = bbox
                x2, y2 = x1 + w, y1 + h
            else:
                # Format is [x1, y1, x2, y2]
                x1, y1, x2, y2 = bbox
        
        # Add padding
        height, width = image.shape[:2]
        x1 = max(0, x1 - padding)
        y1 = max(0, y1 - padding)
        x2 = min(width, x2 + padding)
        y2 = min(height, y2 + padding)
        
        # Crop the image
        cropped = image[y1:y2, x1:x2]
        
        return cropped
    
    def save_crop(self, image, bbox, detection_info=None, padding=10):
        """
        Save a cropped detection.
        
        Args:
            image: Input image (numpy array or path)
            bbox: Bounding box [x1, y1, x2, y2] or [x, y, w, h]
            detection_info: Additional information about the detection
            padding: Padding around the bounding box
            
        Returns:
            Path to the saved crop
        """
        # Load image if path is provided
        if isinstance(image, str):
            image = cv2.imread(image)
            if image is None:
                raise ValueError(f"Could not load image: {image}")
        
        # Crop the detection
        cropped = self.crop_detection(image, bbox, padding)
        
        # Create filename
        self.crop_count += 1
        timestamp = int(time.time())
        if detection_info and 'type' in detection_info:
            filename = f"crop_{detection_info['type']}_{timestamp}_{self.crop_count}.jpg"
        else:
            filename = f"crop_{timestamp}_{self.crop_count}.jpg"
            
        # Save the crop
        output_path = os.path.join(self.output_dir, filename)
        cv2.imwrite(output_path, cropped)
        
        return output_path
    
    def create_zoom_sequence(self, image, bbox, num_frames=5, zoom_start=1.0, zoom_end=3.0, padding=10):
        """
        Create a sequence of frames zooming in on a detection.
        
        Args:
            image: Input image (numpy array or path)
            bbox: Bounding box [x1, y1, x2, y2] or [x, y, w, h]
            num_frames: Number of frames in the sequence
            zoom_start: Starting zoom level
            zoom_end: Ending zoom level
            padding: Padding around the bounding box
            
        Returns:
            List of frames showing progressive zoom
        """
        # Load image if path is provided
        if isinstance(image, str):
            image = cv2.imread(image)
            if image is None:
                raise ValueError(f"Could not load image: {image}")
        
        # Convert bbox format if needed
        if len(bbox) == 4:
            if bbox[2] < bbox[0] or bbox[3] < bbox[1]:
                # Format is [x, y, width, height]
                x1, y1, w, h = bbox
                x2, y2 = x1 + w, y1 + h
            else:
                # Format is [x1, y1, x2, y2]
                x1, y1, x2, y2 = bbox
        
        # Calculate center of detection
        center_x = (x1 + x2) // 2
        center_y = (y1 + y2) // 2
        
        # Calculate original width and height
        orig_width = x2 - x1 + 2 * padding
        orig_height = y2 - y1 + 2 * padding
        
        # Create sequence of frames with increasing zoom
        sequence = []
        for i in range(num_frames):
            # Calculate zoom level for this frame
            zoom = zoom_start + (zoom_end - zoom_start) * i / (num_frames - 1)
            
            # Calculate new width and height based on zoom
            new_width = int(orig_width / zoom)
            new_height = int(orig_height / zoom)
            
            # Calculate new boundaries
            new_x1 = max(0, center_x - new_width // 2)
            new_y1 = max(0, center_y - new_height // 2)
            new_x2 = min(image.shape[1], new_x1 + new_width)
            new_y2 = min(image.shape[0], new_y1 + new_height)
            
            # Crop the frame
            cropped = image[new_y1:new_y2, new_x1:new_x2]
            
            # Resize to original detection size for consistent sequence
            resized = cv2.resize(cropped, (orig_width, orig_height))
            
            sequence.append(resized)
            
        return sequence
    
    def save_zoom_sequence(self, image, bbox, detection_info=None, num_frames=5, zoom_start=1.0, zoom_end=3.0, padding=10):
        """
        Save a sequence of frames zooming in on a detection.
        
        Args:
            image: Input image (numpy array or path)
            bbox: Bounding box [x1, y1, x2, y2] or [x, y, w, h]
            detection_info: Additional information about the detection
            num_frames: Number of frames in the sequence
            zoom_start: Starting zoom level
            zoom_end: Ending zoom level
            padding: Padding around the bounding box
            
        Returns:
            List of paths to the saved frames
        """
        # Create the sequence
        sequence = self.create_zoom_sequence(image, bbox, num_frames, zoom_start, zoom_end, padding)
        
        # Create base filename
        self.crop_count += 1
        timestamp = int(time.time())
        if detection_info and 'type' in detection_info:
            base_filename = f"sequence_{detection_info['type']}_{timestamp}_{self.crop_count}"
        else:
            base_filename = f"sequence_{timestamp}_{self.crop_count}"
            
        # Save each frame
        output_paths = []
        for i, frame in enumerate(sequence):
            filename = f"{base_filename}_{i+1}.jpg"
            output_path = os.path.join(self.output_dir, 'sequences', filename)
            cv2.imwrite(output_path, frame)
            output_paths.append(output_path)
            
        return output_paths
    
    def create_gif(self, sequence, output_path=None, duration=200):
        """
        Create a GIF from a sequence of frames.
        
        Args:
            sequence: List of frames or paths to frames
            output_path: Path to save the GIF (optional)
            duration: Duration of each frame in milliseconds
            
        Returns:
            Path to the saved GIF
        """
        # Create default output path if not provided
        if output_path is None:
            timestamp = int(time.time())
            output_path = os.path.join(self.output_dir, 'gifs', f"zoom_sequence_{timestamp}.gif")
            
        # Convert frames to PIL Images if they're not already
        images = []
        for frame in sequence:
            if isinstance(frame, str):
                # Frame is a path
                img = Image.open(frame)
            else:
                # Frame is a numpy array
                img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            images.append(img)
            
        # Save as GIF
        images[0].save(
            output_path,
            save_all=True,
            append_images=images[1:],
            duration=duration,
            loop=0
        )
        
        return output_path
    
    def create_mp4(self, sequence, output_path=None, fps=5):
        """
        Create an MP4 video from a sequence of frames.
        
        Args:
            sequence: List of frames or paths to frames
            output_path: Path to save the MP4 (optional)
            fps: Frames per second
            
        Returns:
            Path to the saved MP4
        """
        # Create default output path if not provided
        if output_path is None:
            timestamp = int(time.time())
            output_path = os.path.join(self.output_dir, 'gifs', f"zoom_sequence_{timestamp}.mp4")
            
        # Load frames if paths are provided
        frames = []
        for frame in sequence:
            if isinstance(frame, str):
                # Frame is a path
                img = cv2.imread(frame)
            else:
                # Frame is a numpy array
                img = frame
            frames.append(img)
            
        # Get frame dimensions
        height, width = frames[0].shape[:2]
        
        # Create video writer
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
        
        # Write frames
        for frame in frames:
            out.write(frame)
            
        # Release resources
        out.release()
        
        return output_path
    
    def highlight_detection(self, image, bbox, color=(0, 0, 255), thickness=2, zoom_box=True, zoom_factor=1.5):
        """
        Highlight a detection in an image.
        
        Args:
            image: Input image (numpy array)
            bbox: Bounding box [x1, y1, x2, y2] or [x, y, w, h]
            color: Color of the highlight (B, G, R)
            thickness: Thickness of the highlight
            zoom_box: Whether to add a zoom box effect
            zoom_factor: Factor to scale the zoom box
            
        Returns:
            Image with highlighted detection
        """
        # Create a copy of the image
        result = image.copy()
        
        # Convert bbox format if needed
        if len(bbox) == 4:
            if bbox[2] < bbox[0] or bbox[3] < bbox[1]:
                # Format is [x, y, width, height]
                x1, y1, w, h = bbox
                x2, y2 = x1 + w, y1 + h
            else:
                # Format is [x1, y1, x2, y2]
                x1, y1, x2, y2 = bbox
        
        # Draw bounding box
        cv2.rectangle(result, (x1, y1), (x2, y2), color, thickness)
        
        # Add zoom box effect
        if zoom_box:
            # Calculate center of detection
            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2
            
            # Calculate dimensions of zoom box
            zoom_width = int((x2 - x1) * zoom_factor)
            zoom_height = int((y2 - y1) * zoom_factor)
            
            # Calculate position of zoom box (offset to the right)
            zoom_x1 = min(image.shape[1] - zoom_width, x2 + 20)
            zoom_y1 = max(0, center_y - zoom_height // 2)
            zoom_x2 = zoom_x1 + zoom_width
            zoom_y2 = zoom_y1 + zoom_height
            
            # Draw zoom box
            cv2.rectangle(result, (zoom_x1, zoom_y1), (zoom_x2, zoom_y2), color, thickness)
            
            # Draw connecting lines
            cv2.line(result, (x2, center_y), (zoom_x1, center_y), color, 1)
            
            # Crop and resize the detection
            cropped = image[y1:y2, x1:x2]
            zoomed = cv2.resize(cropped, (zoom_width, zoom_height))
            
            # Place the zoomed detection in the zoom box
            result[zoom_y1:zoom_y2, zoom_x1:zoom_x2] = zoomed
            
        return result
    
    def create_detection_grid(self, crops, grid_size=(3, 3), cell_size=(200, 200), background_color=(255, 255, 255)):
        """
        Create a grid of detection crops.
        
        Args:
            crops: List of cropped images or paths to crops
            grid_size: Size of the grid (rows, cols)
            cell_size: Size of each cell (width, height)
            background_color: Color of the background (B, G, R)
            
        Returns:
            Grid image
        """
        rows, cols = grid_size
        cell_width, cell_height = cell_size
        
        # Create blank grid image
        grid_width = cols * cell_width
        grid_height = rows * cell_height
        grid = np.ones((grid_height, grid_width, 3), dtype=np.uint8) * np.array(background_color, dtype=np.uint8)
        
        # Load crops if paths are provided
        crop_images = []
        for crop in crops:
            if isinstance(crop, str):
                # Crop is a path
                img = cv2.imread(crop)
                if img is not None:
                    crop_images.append(img)
            else:
                # Crop is a numpy array
                crop_images.append(crop)
                
        # Place crops in grid
        for i, crop in enumerate(crop_images):
            if i >= rows * cols:
                break
                
            # Calculate position in grid
            row = i // cols
            col = i % cols
            
            # Calculate position in image
            x = col * cell_width
            y = row * cell_height
            
            # Resize crop to fit cell
            resized = cv2.resize(crop, (cell_width, cell_height))
            
            # Place crop in grid
            grid[y:y+cell_height, x:x+cell_width] = resized
            
        return grid
    
    def save_detection_grid(self, crops, output_path=None, grid_size=(3, 3), cell_size=(200, 200)):
        """
        Save a grid of detection crops.
        
        Args:
            crops: List of cropped images or paths to crops
            output_path: Path to save the grid (optional)
            grid_size: Size of the grid (rows, cols)
            cell_size: Size of each cell (width, height)
            
        Returns:
            Path to the saved grid
        """
        # Create default output path if not provided
        if output_path is None:
            timestamp = int(time.time())
            output_path = os.path.join(self.output_dir, f"detection_grid_{timestamp}.jpg")
            
        # Create the grid
        grid = self.create_detection_grid(crops, grid_size, cell_size)
        
        # Save the grid
        cv2.imwrite(output_path, grid)
        
        return output_path
    
    def create_zoom_animation(self, image, bbox, output_path=None, num_frames=10, zoom_end=3.0, fps=5):
        """
        Create a smooth zoom animation focusing on a detection.
        
        Args:
            image: Input image (numpy array or path)
            bbox: Bounding box [x1, y1, x2, y2] or [x, y, w, h]
            output_path: Path to save the animation (optional)
            num_frames: Number of frames in the animation
            zoom_end: Maximum zoom level
            fps: Frames per second
            
        Returns:
            Path to the saved animation
        """
        # Create default output path if not provided
        if output_path is None:
            timestamp = int(time.time())
            output_path = os.path.join(self.output_dir, 'gifs', f"zoom_animation_{timestamp}.mp4")
            
        # Create the zoom sequence
        sequence = self.create_zoom_sequence(
            image, 
            bbox, 
            num_frames=num_frames, 
            zoom_start=1.0, 
            zoom_end=zoom_end
        )
        
        # Create the animation
        return self.create_mp4(sequence, output_path, fps)
