"""
Integration module for camera control, zoom functionality, and detection system.
This module combines all components into a complete stadium monitoring system.
"""

import os
import cv2
import numpy as np
import time
from PIL import Image
import matplotlib.pyplot as plt

from src.system import StadiumMonitoringSystem
from src.camera_control import CameraController
from src.zoom_processor import ZoomProcessor

class EnhancedStadiumMonitoringSystem:
    """Enhanced stadium monitoring system with camera control and zoom capabilities."""
    
    def __init__(self, config=None):
        """
        Initialize the enhanced monitoring system.
        
        Args:
            config: Configuration dictionary (optional)
        """
        # Default configuration
        self.config = {
            'model_dir': 'models',
            'input_shape': (384, 512, 3),
            'detection_threshold': 0.5,
            'alerts_dir': 'alerts',
            'camera_outputs_dir': 'camera_outputs',
            'zoom_outputs_dir': 'zoom_outputs',
            'zoom_level': 2.5,
            'scan_speed': 15,
            'scan_pattern': 'grid',
            'stadium_sections': {
                'hilal': [0, 0, 256, 384],  # Left half of stadium (x1, y1, x2, y2)
                'ittihad': [256, 0, 512, 384]  # Right half of stadium
            }
        }
        
        # Update with provided config
        if config:
            self.config.update(config)
            
        # Create output directories
        os.makedirs(self.config['camera_outputs_dir'], exist_ok=True)
        os.makedirs(self.config['zoom_outputs_dir'], exist_ok=True)
        
        # Initialize components
        self.monitoring_system = StadiumMonitoringSystem(config=self.config)
        self.camera_controller = CameraController(output_dir=self.config['camera_outputs_dir'])
        self.zoom_processor = ZoomProcessor(output_dir=self.config['zoom_outputs_dir'])
        
        # Configure camera controller
        self.camera_controller.scan_speed = self.config['scan_speed']
        self.camera_controller.scan_pattern = self.config['scan_pattern']
        
        # Initialize system state
        self.is_initialized = False
        
    def initialize(self, detector_path=None, behavior_classifier_path=None, team_detector_path=None):
        """
        Initialize the system components.
        
        Args:
            detector_path: Path to the trained detector model (optional)
            behavior_classifier_path: Path to the trained behavior classifier (optional)
            team_detector_path: Path to the trained team detector (optional)
        """
        # Initialize the monitoring system
        self.monitoring_system.initialize(
            detector_path=detector_path,
            behavior_classifier_path=behavior_classifier_path,
            team_detector_path=team_detector_path
        )
        
        self.is_initialized = True
        print("Enhanced stadium monitoring system initialized successfully.")
        
    def process_image(self, image_path, output_path=None, generate_alerts=True, zoom_on_detections=True):
        """
        Process a single image with camera control and zoom.
        
        Args:
            image_path: Path to the input image
            output_path: Path to save the output image (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            zoom_on_detections: Whether to zoom in on detections
            
        Returns:
            detections: List of detections
            alerts: List of generated alerts
            results: Dictionary with paths to all generated outputs
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        # Process the image with the monitoring system
        detections, alerts = self.monitoring_system.process_image(
            image_path,
            output_path=None,  # We'll create our own output with zoom effects
            generate_alerts=generate_alerts
        )
        
        # Load the original image for camera operations
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
            
        # Create results dictionary
        results = {
            'crops': [],
            'zooms': [],
            'sequences': [],
            'animations': [],
            'grids': []
        }
        
        # Process each detection with camera control and zoom
        problematic_crops = []
        
        for i, det in enumerate(detections):
            # Extract bounding box
            bbox = det['bbox']
            
            # Create detection info
            detection_info = {
                'type': det['action'],
                'team': det['team'],
                'confidence': det['action_score']
            }
            
            # Zoom in on the detection
            if zoom_on_detections:
                # Save a cropped image
                crop_path = self.zoom_processor.save_crop(
                    image, 
                    bbox, 
                    detection_info
                )
                results['crops'].append(crop_path)
                
                # For problematic behaviors, create enhanced visualizations
                if det['action'] in ['fighting', 'throwing']:
                    problematic_crops.append(crop_path)
                    
                    # Create a zoom sequence
                    sequence_paths = self.zoom_processor.save_zoom_sequence(
                        image,
                        bbox,
                        detection_info
                    )
                    results['sequences'].append(sequence_paths)
                    
                    # Create a GIF from the sequence
                    gif_path = os.path.join(
                        self.config['zoom_outputs_dir'],
                        'gifs',
                        f"zoom_{det['action']}_{i+1}.gif"
                    )
                    self.zoom_processor.create_gif(
                        sequence_paths,
                        gif_path
                    )
                    results['zooms'].append(gif_path)
                    
                    # Create a smooth zoom animation
                    animation_path = os.path.join(
                        self.config['zoom_outputs_dir'],
                        'gifs',
                        f"animation_{det['action']}_{i+1}.mp4"
                    )
                    self.zoom_processor.create_zoom_animation(
                        image,
                        bbox,
                        animation_path
                    )
                    results['animations'].append(animation_path)
        
        # Create a grid of problematic detections if any
        if problematic_crops:
            grid_path = os.path.join(
                self.config['zoom_outputs_dir'],
                'detection_grid.jpg'
            )
            self.zoom_processor.save_detection_grid(
                problematic_crops,
                grid_path
            )
            results['grids'].append(grid_path)
        
        # Create output image with highlighted detections
        if output_path:
            output_img = image.copy()
            
            for det in detections:
                bbox = det['bbox']
                
                # Determine color based on action
                color = (0, 0, 255) if det['action'] in ['fighting', 'throwing'] else (0, 255, 0)
                
                # Highlight detection with zoom box for problematic behaviors
                if det['action'] in ['fighting', 'throwing']:
                    output_img = self.zoom_processor.highlight_detection(
                        output_img,
                        bbox,
                        color=color,
                        zoom_box=True
                    )
                else:
                    # Just draw bounding box for normal behaviors
                    x1, y1, x2, y2 = bbox
                    cv2.rectangle(output_img, (x1, y1), (x2, y2), color, 2)
                    
                    # Draw label
                    label = f"{det['team']}/{det['action']}"
                    cv2.putText(output_img, label, (x1, y1-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            
            # Save the output image
            cv2.imwrite(output_path, output_img)
        
        return detections, alerts, results
    
    def process_video(self, video_path, output_path=None, generate_alerts=True, zoom_on_detections=True, frame_interval=5):
        """
        Process a video with camera control and zoom.
        
        Args:
            video_path: Path to the input video
            output_path: Path to save the output video (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            zoom_on_detections: Whether to zoom in on detections
            frame_interval: Process every Nth frame to reduce computation
            
        Returns:
            all_detections: List of detections for each processed frame
            all_alerts: List of generated alerts
            all_results: Dictionary with paths to all generated outputs
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        # Open video
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise ValueError(f"Could not open video: {video_path}")
            
        # Get video properties
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        # Create output video writer if needed
        out = None
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
            
        # Create output directory for video frames
        frames_dir = os.path.join(self.config['zoom_outputs_dir'], 'video_frames')
        os.makedirs(frames_dir, exist_ok=True)
        
        # Process frames
        all_detections = []
        all_alerts = []
        all_results = {
            'crops': [],
            'zooms': [],
            'sequences': [],
            'animations': [],
            'grids': [],
            'frames': []
        }
        
        frame_count = 0
        problematic_frames = []
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            # Process every Nth frame
            if frame_count % frame_interval == 0:
                # Save frame as temporary image
                temp_path = os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg')
                cv2.imwrite(temp_path, frame)
                
                # Process the frame
                detections, alerts = self.monitoring_system.process_image(
                    temp_path, 
                    output_path=None,
                    generate_alerts=generate_alerts
                )
                
                all_detections.append(detections)
                all_alerts.extend(alerts)
                
                # Check if frame has problematic behaviors
                has_problematic = any(det['action'] in ['fighting', 'throwing'] for det in detections)
                
                # Process each detection with camera control and zoom
                frame_crops = []
                
                for i, det in enumerate(detections):
                    # Extract bounding box
                    bbox = det['bbox']
                    
                    # Create detection info
                    detection_info = {
                        'type': det['action'],
                        'team': det['team'],
                        'confidence': det['action_score'],
                        'frame': frame_count
                    }
                    
                    # Zoom in on the detection
                    if zoom_on_detections:
                        # Save a cropped image
                        crop_path = self.zoom_processor.save_crop(
                            frame, 
                            bbox, 
                            detection_info
                        )
                        frame_crops.append(crop_path)
                        all_results['crops'].append(crop_path)
                        
                        # For problematic behaviors, create enhanced visualizations
                        if det['action'] in ['fighting', 'throwing']:
                            # Create a zoom sequence
                            sequence_paths = self.zoom_processor.save_zoom_sequence(
                                frame,
                                bbox,
                                detection_info
                            )
                            all_results['sequences'].append(sequence_paths)
                            
                            # Create a GIF from the sequence
                            gif_path = os.path.join(
                                self.config['zoom_outputs_dir'],
                                'gifs',
                                f"zoom_{det['action']}_frame{frame_count}_{i+1}.gif"
                            )
                            self.zoom_processor.create_gif(
                                sequence_paths,
                                gif_path
                            )
                            all_results['zooms'].append(gif_path)
                    
                    # Draw bounding box on frame
                    xmin, ymin, xmax, ymax = bbox
                    
                    # Determine color based on action
                    color = (0, 0, 255) if det['action'] in ['fighting', 'throwing'] else (0, 255, 0)
                    
                    # Highlight detection with zoom box for problematic behaviors
                    if det['action'] in ['fighting', 'throwing']:
                        frame = self.zoom_processor.highlight_detection(
                            frame,
                            bbox,
                            color=color,
                            zoom_box=True
                        )
                    else:
                        # Just draw bounding box for normal behaviors
                        cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), color, 2)
                        
                        # Draw label
                        label = f"{det['team']}/{det['action']}"
                        cv2.putText(frame, label, (xmin, ymin-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                
                # Save problematic frames
                if has_problematic:
                    frame_path = os.path.join(frames_dir, f"frame_{frame_count}.jpg")
                    cv2.imwrite(frame_path, frame)
                    problematic_frames.append(frame_path)
                    all_results['frames'].append(frame_path)
            
            # Write frame to output video
            if out:
                out.write(frame)
                
            frame_count += 1
            
            # Print progress
            if frame_count % 100 == 0:
                print(f"Processed {frame_count}/{total_frames} frames ({frame_count/total_frames*100:.1f}%)")
        
        # Create a grid of problematic frames if any
        if problematic_frames:
            grid_path = os.path.join(
                self.config['zoom_outputs_dir'],
                'problematic_frames_grid.jpg'
            )
            self.zoom_processor.save_detection_grid(
                problematic_frames,
                grid_path,
                grid_size=(2, 3),
                cell_size=(320, 240)
            )
            all_results['grids'].append(grid_path)
                
        # Release resources
        cap.release()
        if out:
            out.release()
            
        # Clean up temporary files
        if os.path.exists(os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg')):
            os.remove(os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg'))
            
        return all_detections, all_alerts, all_results
    
    def process_live_feed(self, camera_id=0, output_path=None, generate_alerts=True, zoom_on_detections=True, duration=None):
        """
        Process a live camera feed with camera control and zoom.
        
        Args:
            camera_id: Camera ID or RTSP URL
            output_path: Path to save the output video (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            zoom_on_detections: Whether to zoom in on detections
            duration: Duration to process in seconds (None for indefinite)
            
        Returns:
            all_alerts: List of generated alerts
            all_results: Dictionary with paths to all generated outputs
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        # Open camera
        cap = cv2.VideoCapture(camera_id)
        if not cap.isOpened():
            raise ValueError(f"Could not open camera: {camera_id}")
            
        # Get video properties
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        
        # Create output video writer if needed
        out = None
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
            
        # Create output directory for live frames
        frames_dir = os.path.join(self.config['zoom_outputs_dir'], 'live_frames')
        os.makedirs(frames_dir, exist_ok=True)
        
        # Create windows for display
        cv2.namedWindow('Stadium Monitoring', cv2.WINDOW_NORMAL)
        cv2.namedWindow('Detection Zoom', cv2.WINDOW_NORMAL)
        
        # Process frames
        all_alerts = []
        all_results = {
            'crops': [],
            'zooms': [],
            'sequences': [],
            'animations': [],
            'grids': [],
            'frames': []
        }
        
        frame_count = 0
        start_time = time.time()
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            # Check if duration exceeded
            if duration and time.time() - start_time > duration:
                break
                
            # Process every 5th frame to reduce computation
            if frame_count % 5 == 0:
                # Save frame as temporary image
                temp_path = os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg')
                cv2.imwrite(temp_path, frame)
                
                # Process the frame
                detections, alerts = self.monitoring_system.process_image(
                    temp_path, 
                    output_path=None,
                    generate_alerts=generate_alerts
                )
                
                all_alerts.extend(alerts)
                
                # Check if frame has problematic behaviors
                has_problematic = any(det['action'] in ['fighting', 'throwing'] for det in detections)
                
                # Process each detection with camera control and zoom
                for i, det in enumerate(detections):
                    # Extract bounding box
                    bbox = det['bbox']
                    
                    # Create detection info
                    detection_info = {
                        'type': det['action'],
                        'team': det['team'],
                        'confidence': det['action_score']
                    }
                    
                    # Zoom in on the detection
                    if zoom_on_detections:
                        # Get zoomed crop
                        zoomed = self.zoom_processor.crop_detection(
                            frame, 
                            bbox, 
                            padding=20
                        )
                        
                        # Display the zoomed detection
                        cv2.imshow('Detection Zoom', zoomed)
                        
                        # Save a cropped image
                        crop_path = self.zoom_processor.save_crop(
                            frame, 
                            bbox, 
                            detection_info
                        )
                        all_results['crops'].append(crop_path)
                        
                        # For problematic behaviors, create enhanced visualizations
                        if det['action'] in ['fighting', 'throwing']:
                            # Save the problematic frame
                            frame_path = os.path.join(frames_dir, f"frame_{int(time.time())}_{i+1}.jpg")
                            cv2.imwrite(frame_path, frame)
                            all_results['frames'].append(frame_path)
                            
                            # Create a zoom sequence
                            sequence_paths = self.zoom_processor.save_zoom_sequence(
                                frame,
                                bbox,
                                detection_info
                            )
                            all_results['sequences'].append(sequence_paths)
                            
                            # Create a GIF from the sequence
                            gif_path = os.path.join(
                                self.config['zoom_outputs_dir'],
                                'gifs',
                                f"zoom_{det['action']}_{int(time.time())}_{i+1}.gif"
                            )
                            self.zoom_processor.create_gif(
                                sequence_paths,
                                gif_path
                            )
                            all_results['zooms'].append(gif_path)
                    
                    # Highlight detection with zoom box for problematic behaviors
                    if det['action'] in ['fighting', 'throwing']:
                        color = (0, 0, 255)  # Red for problematic behaviors
                        frame = self.zoom_processor.highlight_detection(
                            frame,
                            bbox,
                            color=color,
                            zoom_box=True
                        )
                    else:
                        # Just draw bounding box for normal behaviors
                        color = (0, 255, 0)  # Green for normal behaviors
                        xmin, ymin, xmax, ymax = bbox
                        cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), color, 2)
                        
                        # Draw label
                        label = f"{det['team']}/{det['action']}"
                        cv2.putText(frame, label, (xmin, ymin-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            
            # Display frame
            cv2.imshow('Stadium Monitoring', frame)
            
            # Write frame to output video
            if out:
                out.write(frame)
                
            frame_count += 1
            
            # Exit on 'q' key press
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
        # Release resources
        cap.release()
        if out:
            out.release()
        cv2.destroyAllWindows()
        
        # Clean up temporary files
        if os.path.exists(os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg')):
            os.remove(os.path.join(self.config['camera_outputs_dir'], 'temp_frame.jpg'))
            
        return all_alerts, all_results
    
    def scan_and_monitor(self, image_path, output_path=None, generate_alerts=True):
        """
        Scan an image and monitor for problematic behaviors with camera movement.
        
        Args:
            image_path: Path to the input image
            output_path: Path to save the output image (optional)
            generate_alerts: Whether to generate alerts for problematic behaviors
            
        Returns:
            detections: List of detections
            alerts: List of generated alerts
            results: Dictionary with paths to all generated outputs
        """
        if not self.is_initialized:
            raise RuntimeError("System not initialized. Call initialize() first.")
            
        # Load the image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
            
        height, width = image.shape[:2]
        
        # Create a copy for visualization
        vis_image = image.copy()
        
        # Create output directory for scanned crops
        scans_dir = os.path.join(self.config['zoom_outputs_dir'], 'scans')
        os.makedirs(scans_dir, exist_ok=True)
        
        # Initialize results
        all_detections = []
        all_alerts = []
        results = {
            'crops': [],
            'zooms': [],
            'sequences': [],
            'animations': [],
            'grids': [],
            'scans': []
        }
        
        # Scan the image
        scan_count = 0
        problematic_crops = []
        
        for position, cropped in self.camera_controller.scan_area(image, width, height):
            scan_count += 1
            
            # Save the cropped view
            scan_path = os.path.join(scans_dir, f"scan_{scan_count}.jpg")
            cv2.imwrite(scan_path, cropped)
            results['scans'].append(scan_path)
            
            # Process the cropped view
            temp_path = os.path.join(self.config['camera_outputs_dir'], 'temp_scan.jpg')
            cv2.imwrite(temp_path, cropped)
            
            # Process the cropped view with the monitoring system
            try:
                detections, alerts = self.monitoring_system.process_image(
                    temp_path, 
                    output_path=None,
                    generate_alerts=generate_alerts
                )
                
                # If detections found, add to results
                if detections:
                    all_detections.extend(detections)
                    all_alerts.extend(alerts)
                    
                    # Process each detection
                    for det in detections:
                        # Adjust bounding box to original image coordinates
                        x, y = position
                        x_offset = max(0, x - width // (2 * self.camera_controller.zoom_level))
                        y_offset = max(0, y - height // (2 * self.camera_controller.zoom_level))
                        
                        bbox = det['bbox']
                        adjusted_bbox = [
                            bbox[0] + x_offset,
                            bbox[1] + y_offset,
                            bbox[2] + x_offset,
                            bbox[3] + y_offset
                        ]
                        
                        # Create detection info
                        detection_info = {
                            'type': det['action'],
                            'team': det['team'],
                            'confidence': det['action_score']
                        }
                        
                        # Save a zoomed crop
                        crop_path = self.zoom_processor.save_crop(
                            image, 
                            adjusted_bbox, 
                            detection_info
                        )
                        results['crops'].append(crop_path)
                        
                        # For problematic behaviors, create enhanced visualizations
                        if det['action'] in ['fighting', 'throwing']:
                            problematic_crops.append(crop_path)
                            
                            # Create a zoom sequence
                            sequence_paths = self.zoom_processor.save_zoom_sequence(
                                image,
                                adjusted_bbox,
                                detection_info
                            )
                            results['sequences'].append(sequence_paths)
                            
                            # Create a GIF from the sequence
                            gif_path = os.path.join(
                                self.config['zoom_outputs_dir'],
                                'gifs',
                                f"zoom_{det['action']}_{scan_count}.gif"
                            )
                            self.zoom_processor.create_gif(
                                sequence_paths,
                                gif_path
                            )
                            results['zooms'].append(gif_path)
                            
                            # Create a smooth zoom animation
                            animation_path = os.path.join(
                                self.config['zoom_outputs_dir'],
                                'gifs',
                                f"animation_{det['action']}_{scan_count}.mp4"
                            )
                            self.zoom_processor.create_zoom_animation(
                                image,
                                adjusted_bbox,
                                animation_path
                            )
                            results['animations'].append(animation_path)
                        
                        # Highlight detection in visualization image
                        if det['action'] in ['fighting', 'throwing']:
                            color = (0, 0, 255)  # Red for problematic behaviors
                            vis_image = self.zoom_processor.highlight_detection(
                                vis_image,
                                adjusted_bbox,
                                color=color,
                                zoom_box=True
                            )
                        else:
                            # Just draw bounding box for normal behaviors
                            color = (0, 255, 0)  # Green for normal behaviors
                            xmin, ymin, xmax, ymax = adjusted_bbox
                            cv2.rectangle(vis_image, (xmin, ymin), (xmax, ymax), color, 2)
                            
                            # Draw label
                            label = f"{det['team']}/{det['action']}"
                            cv2.putText(vis_image, label, (xmin, ymin-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            except Exception as e:
                print(f"Error processing scan {scan_count}: {e}")
        
        # Create a grid of problematic detections if any
        if problematic_crops:
            grid_path = os.path.join(
                self.config['zoom_outputs_dir'],
                'problematic_detections_grid.jpg'
            )
            self.zoom_processor.save_detection_grid(
                problematic_crops,
                grid_path
            )
            results['grids'].append(grid_path)
                
        # Save the visualization image
        if output_path:
            cv2.imwrite(output_path, vis_image)
            
        # Clean up temporary files
        if os.path.exists(os.path.join(self.config['camera_outputs_dir'], 'temp_scan.jpg')):
            os.remove(os.path.join(self.config['camera_outputs_dir'], 'temp_scan.jpg'))
            
        print(f"Completed {scan_count} scans, found {len(all_detections)} detections")
        
        return all_detections, all_alerts, results
    
    def generate_report(self, output_path=None):
        """
        Generate a summary report of the monitoring system.
        
        Args:
            output_path: Path to save the report (optional)
            
        Returns:
            Report text
        """
        # Generate alert report
        report = self.monitoring_system.alert_system.generate_alert_report(output_path)
        
        return report
    
    def visualize_alerts(self, output_path=None):
        """
        Visualize the distribution of alerts.
        
        Args:
            output_path: Path to save the visualization (optional)
            
        Returns:
            Matplotlib figure
        """
        # Visualize alert distribution
        fig = self.monitoring_system.alert_system.visualize_alert_distribution(output_path)
        
        return fig
