"""
Unit tests for individual components of the stadium crowd monitoring system.
"""

import os
import sys
import unittest
import numpy as np
import tensorflow as tf
from PIL import Image

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.data_utils import StadiumDataset
from src.model import FanDetectionModel
from src.behavior_classifier import BehaviorClassifier
from src.team_detector import TeamAffiliationDetector
from src.alert_system import SecurityAlertSystem

class TestDataUtils(unittest.TestCase):
    """Test cases for the data utilities module."""
    
    def setUp(self):
        """Set up test environment."""
        self.dataset_dir = 'stadium_dataset'
        self.dataset = StadiumDataset(self.dataset_dir)
        
    def test_dataset_initialization(self):
        """Test dataset initialization."""
        self.assertEqual(self.dataset.dataset_dir, self.dataset_dir)
        self.assertEqual(self.dataset.images_dir, os.path.join(self.dataset_dir, 'images'))
        self.assertEqual(self.dataset.annotations_file, os.path.join(self.dataset_dir, 'annotations', 'labels.json'))
        
    def test_team_action_mapping(self):
        """Test team and action mappings."""
        self.assertEqual(self.dataset.team_mapping, {'hilal': 0, 'ittihad': 1})
        self.assertEqual(self.dataset.action_mapping, {'sitting': 0, 'cheering': 1, 'fighting': 2, 'throwing': 3})

class TestModel(unittest.TestCase):
    """Test cases for the model module."""
    
    def setUp(self):
        """Set up test environment."""
        self.input_shape = (384, 512, 3)
        self.model = FanDetectionModel(input_shape=self.input_shape)
        
    def test_model_initialization(self):
        """Test model initialization."""
        self.assertEqual(self.model.input_shape, self.input_shape)
        self.assertEqual(self.model.num_classes, 1)
        self.assertEqual(self.model.num_teams, 2)
        self.assertEqual(self.model.num_actions, 4)
        
    def test_model_build(self):
        """Test model building."""
        model = self.model.build_model()
        self.assertIsNotNone(model)
        self.assertEqual(len(model.outputs), 4)  # bbox, class, team, action outputs

class TestBehaviorClassifier(unittest.TestCase):
    """Test cases for the behavior classifier module."""
    
    def setUp(self):
        """Set up test environment."""
        self.input_shape = (128, 128, 3)
        self.classifier = BehaviorClassifier(input_shape=self.input_shape)
        
    def test_classifier_initialization(self):
        """Test classifier initialization."""
        self.assertEqual(self.classifier.input_shape, self.input_shape)
        self.assertEqual(self.classifier.num_actions, 4)
        
    def test_action_mapping(self):
        """Test action mappings."""
        self.assertEqual(self.classifier.action_mapping, {0: 'sitting', 1: 'cheering', 2: 'fighting', 3: 'throwing'})
        self.assertEqual(self.classifier.action_mapping_inv, {'sitting': 0, 'cheering': 1, 'fighting': 2, 'throwing': 3})
        
    def test_problematic_behavior_evaluation(self):
        """Test problematic behavior evaluation."""
        # Test fighting (problematic)
        is_problematic, severity = self.classifier.evaluate_problematic_behavior('fighting', 0.8)
        self.assertTrue(is_problematic)
        self.assertGreater(severity, 0.0)
        
        # Test throwing (problematic)
        is_problematic, severity = self.classifier.evaluate_problematic_behavior('throwing', 0.9)
        self.assertTrue(is_problematic)
        self.assertGreater(severity, 0.0)
        
        # Test sitting (not problematic)
        is_problematic, severity = self.classifier.evaluate_problematic_behavior('sitting', 0.95)
        self.assertFalse(is_problematic)
        self.assertEqual(severity, 0.0)
        
        # Test cheering (not problematic)
        is_problematic, severity = self.classifier.evaluate_problematic_behavior('cheering', 0.85)
        self.assertFalse(is_problematic)
        self.assertEqual(severity, 0.0)

class TestTeamDetector(unittest.TestCase):
    """Test cases for the team detector module."""
    
    def setUp(self):
        """Set up test environment."""
        self.input_shape = (128, 128, 3)
        self.detector = TeamAffiliationDetector(input_shape=self.input_shape)
        
    def test_detector_initialization(self):
        """Test detector initialization."""
        self.assertEqual(self.detector.input_shape, self.input_shape)
        self.assertEqual(self.detector.num_teams, 2)
        
    def test_team_mapping(self):
        """Test team mappings."""
        self.assertEqual(self.detector.team_mapping, {0: 'hilal', 1: 'ittihad'})
        self.assertEqual(self.detector.team_mapping_inv, {'hilal': 0, 'ittihad': 1})
        
    def test_misplaced_fan_detection(self):
        """Test misplaced fan detection."""
        # Define stadium sections
        stadium_sections = {
            'hilal': [0, 0, 256, 384],  # Left half
            'ittihad': [256, 0, 512, 384]  # Right half
        }
        
        # Test hilal fan in hilal section (not misplaced)
        is_misplaced, correct_section = self.detector.detect_misplaced_fans('hilal', (100, 200), stadium_sections)
        self.assertFalse(is_misplaced)
        
        # Test ittihad fan in ittihad section (not misplaced)
        is_misplaced, correct_section = self.detector.detect_misplaced_fans('ittihad', (400, 200), stadium_sections)
        self.assertFalse(is_misplaced)
        
        # Test hilal fan in ittihad section (misplaced)
        is_misplaced, correct_section = self.detector.detect_misplaced_fans('hilal', (400, 200), stadium_sections)
        self.assertTrue(is_misplaced)
        self.assertEqual(correct_section, 'hilal')
        
        # Test ittihad fan in hilal section (misplaced)
        is_misplaced, correct_section = self.detector.detect_misplaced_fans('ittihad', (100, 200), stadium_sections)
        self.assertTrue(is_misplaced)
        self.assertEqual(correct_section, 'ittihad')

class TestAlertSystem(unittest.TestCase):
    """Test cases for the alert system module."""
    
    def setUp(self):
        """Set up test environment."""
        self.output_dir = 'test_alerts'
        self.alert_system = SecurityAlertSystem(output_dir=self.output_dir)
        
    def tearDown(self):
        """Clean up after tests."""
        # Remove test directory if it exists
        import shutil
        if os.path.exists(self.output_dir):
            shutil.rmtree(self.output_dir)
        
    def test_alert_system_initialization(self):
        """Test alert system initialization."""
        self.assertEqual(self.alert_system.output_dir, self.output_dir)
        self.assertEqual(self.alert_system.alerts_log, [])
        self.assertEqual(self.alert_system.alert_count, 0)
        
        # Check if directories were created
        self.assertTrue(os.path.exists(self.output_dir))
        self.assertTrue(os.path.exists(os.path.join(self.output_dir, 'images')))
        
    def test_alert_generation(self):
        """Test alert generation."""
        # Create a test image
        test_image = Image.new('RGB', (512, 384), color='white')
        
        # Generate an alert
        detection = {'bbox': [100, 100, 200, 200]}
        alert_id = self.alert_system.generate_alert(
            image=test_image,
            detection=detection,
            alert_type='fighting',
            location='Section A',
            confidence=0.85,
            details='Hilal fan fighting'
        )
        
        # Check if alert was generated
        self.assertIsNotNone(alert_id)
        self.assertEqual(self.alert_system.alert_count, 1)
        self.assertEqual(len(self.alert_system.alerts_log), 1)
        
        # Check alert data
        alert = self.alert_system.alerts_log[0]
        self.assertEqual(alert['alert_id'], alert_id)
        self.assertEqual(alert['alert_type'], 'fighting')
        self.assertEqual(alert['location'], 'Section A')
        self.assertEqual(alert['confidence'], 0.85)
        self.assertEqual(alert['details'], 'Hilal fan fighting')
        
        # Check if image was saved
        self.assertTrue(os.path.exists(alert['image_path']))

if __name__ == '__main__':
    unittest.main()
