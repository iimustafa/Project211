"""
Test script for the enhanced stadium monitoring system with camera control and zoom functionality.
"""

import os
import sys
import unittest
import cv2
import numpy as np
import shutil

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.camera_control import CameraController
from src.zoom_processor import ZoomProcessor
from src.enhanced_system import EnhancedStadiumMonitoringSystem

class TestEnhancedSystem(unittest.TestCase):
    """Test cases for the enhanced stadium monitoring system."""
    
    def setUp(self):
        """Set up test environment."""
        # Create test directories
        self.test_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data')
        self.output_dir = os.path.join(self.test_dir, 'output')
        self.camera_dir = os.path.join(self.test_dir, 'camera_outputs')
        self.zoom_dir = os.path.join(self.test_dir, 'zoom_outputs')
        
        os.makedirs(self.test_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.camera_dir, exist_ok=True)
        os.makedirs(self.zoom_dir, exist_ok=True)
        
        # Create a test image
        self.test_image = os.path.join(self.test_dir, 'test_image.jpg')
        self._create_test_image()
        
        # Initialize components
        self.camera_controller = CameraController(output_dir=self.camera_dir)
        self.zoom_processor = ZoomProcessor(output_dir=self.zoom_dir)
        
        # Initialize the enhanced system
        self.system = EnhancedStadiumMonitoringSystem(config={
            'model_dir': 'models',
            'alerts_dir': self.output_dir,
            'camera_outputs_dir': self.camera_dir,
            'zoom_outputs_dir': self.zoom_dir,
            'zoom_level': 2.0,
            'scan_speed': 20,
            'scan_pattern': 'grid',
            'stadium_sections': {
                'hilal': [0, 0, 256, 384],  # Left half of stadium
                'ittihad': [256, 0, 512, 384]  # Right half of stadium
            }
        })
        
    def tearDown(self):
        """Clean up after tests."""
        # Remove test directories
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
    
    def _create_test_image(self):
        """Create a test image with simulated fans."""
        # Create a blank image
        image = np.ones((384, 512, 3), dtype=np.uint8) * 150  # Gray background
        
        # Draw some "seats"
        for y in range(100, 350, 30):
            cv2.rectangle(image, (10, y), (502, y + 20), (80, 80, 80), -1)
        
        # Draw some "fans"
        # Hilal fan (blue) sitting
        cv2.rectangle(image, (100, 150), (130, 200), (255, 0, 0), -1)  # Blue
        cv2.circle(image, (115, 140), 15, (255, 224, 189), -1)  # Face
        
        # Hilal fan (blue) cheering
        cv2.rectangle(image, (200, 150), (230, 200), (255, 0, 0), -1)  # Blue
        cv2.circle(image, (215, 140), 15, (255, 224, 189), -1)  # Face
        cv2.line(image, (215, 150), (190, 130), (255, 0, 0), 5)  # Arm up
        cv2.line(image, (215, 150), (240, 130), (255, 0, 0), 5)  # Arm up
        
        # Ittihad fan (gold) sitting
        cv2.rectangle(image, (300, 150), (330, 200), (0, 215, 255), -1)  # Gold
        cv2.circle(image, (315, 140), 15, (255, 224, 189), -1)  # Face
        
        # Ittihad fan (gold) fighting
        cv2.rectangle(image, (400, 150), (430, 200), (0, 215, 255), -1)  # Gold
        cv2.circle(image, (415, 140), 15, (255, 224, 189), -1)  # Face
        cv2.line(image, (415, 150), (390, 160), (0, 215, 255), 5)  # Arm fighting
        cv2.line(image, (415, 150), (440, 160), (0, 215, 255), 5)  # Arm fighting
        
        # Save the image
        cv2.imwrite(self.test_image, image)
    
    def test_camera_controller(self):
        """Test the camera controller functionality."""
        # Load the test image
        image = cv2.imread(self.test_image)
        self.assertIsNotNone(image, "Failed to load test image")
        
        # Test camera movement
        self.camera_controller.set_position((100, 150))
        self.assertEqual(self.camera_controller.current_position, (100, 150), "Failed to set camera position")
        
        # Test zoom level
        self.camera_controller.zoom(2.0)
        self.assertEqual(self.camera_controller.zoom_level, 2.0, "Failed to set zoom level")
        
        # Test get current view
        view = self.camera_controller.get_current_view(image)
        self.assertIsNotNone(view, "Failed to get current view")
        self.assertLess(view.shape[0], image.shape[0], "View should be smaller than original image")
        self.assertLess(view.shape[1], image.shape[1], "View should be smaller than original image")
        
        # Test zoom to detection
        bbox = [100, 150, 130, 200]  # Hilal fan sitting
        zoomed = self.camera_controller.zoom_to_detection(image, bbox)
        self.assertIsNotNone(zoomed, "Failed to zoom to detection")
        
        # Test save detection crop
        crop_path = self.camera_controller.save_detection_crop(image, bbox, {'type': 'sitting', 'team': 'hilal'})
        self.assertTrue(os.path.exists(crop_path), "Failed to save detection crop")
        
        # Test create detection sequence
        sequence = self.camera_controller.create_detection_sequence(image, bbox)
        self.assertEqual(len(sequence), 5, "Sequence should have 5 frames")
        
        # Test save detection sequence
        sequence_paths = self.camera_controller.save_detection_sequence(image, bbox, {'type': 'sitting', 'team': 'hilal'})
        self.assertEqual(len(sequence_paths), 5, "Should have saved 5 sequence frames")
        for path in sequence_paths:
            self.assertTrue(os.path.exists(path), f"Failed to save sequence frame: {path}")
    
    def test_zoom_processor(self):
        """Test the zoom processor functionality."""
        # Load the test image
        image = cv2.imread(self.test_image)
        self.assertIsNotNone(image, "Failed to load test image")
        
        # Test crop detection
        bbox = [400, 150, 430, 200]  # Ittihad fan fighting
        cropped = self.zoom_processor.crop_detection(image, bbox)
        self.assertIsNotNone(cropped, "Failed to crop detection")
        self.assertLess(cropped.shape[0], image.shape[0], "Crop should be smaller than original image")
        self.assertLess(cropped.shape[1], image.shape[1], "Crop should be smaller than original image")
        
        # Test save crop
        crop_path = self.zoom_processor.save_crop(image, bbox, {'type': 'fighting', 'team': 'ittihad'})
        self.assertTrue(os.path.exists(crop_path), "Failed to save crop")
        
        # Test create zoom sequence
        sequence = self.zoom_processor.create_zoom_sequence(image, bbox)
        self.assertEqual(len(sequence), 5, "Sequence should have 5 frames")
        
        # Test save zoom sequence
        sequence_paths = self.zoom_processor.save_zoom_sequence(image, bbox, {'type': 'fighting', 'team': 'ittihad'})
        self.assertEqual(len(sequence_paths), 5, "Should have saved 5 sequence frames")
        for path in sequence_paths:
            self.assertTrue(os.path.exists(path), f"Failed to save sequence frame: {path}")
        
        # Test create GIF
        gif_path = os.path.join(self.zoom_dir, 'test.gif')
        self.zoom_processor.create_gif(sequence_paths, gif_path)
        self.assertTrue(os.path.exists(gif_path), "Failed to create GIF")
        
        # Test highlight detection
        highlighted = self.zoom_processor.highlight_detection(image, bbox)
        self.assertIsNotNone(highlighted, "Failed to highlight detection")
        self.assertEqual(highlighted.shape, image.shape, "Highlighted image should have same shape as original")
        
        # Test create detection grid
        crops = [crop_path]
        grid = self.zoom_processor.create_detection_grid(crops)
        self.assertIsNotNone(grid, "Failed to create detection grid")
        
        # Test save detection grid
        grid_path = os.path.join(self.zoom_dir, 'test_grid.jpg')
        self.zoom_processor.save_detection_grid(crops, grid_path)
        self.assertTrue(os.path.exists(grid_path), "Failed to save detection grid")
    
    def test_enhanced_system_initialization(self):
        """Test the enhanced system initialization."""
        # Test initialization without models (should use dummy models)
        self.system.initialize()
        self.assertTrue(self.system.is_initialized, "System should be initialized")
        
        # Verify components are initialized
        self.assertIsNotNone(self.system.monitoring_system, "Monitoring system should be initialized")
        self.assertIsNotNone(self.system.camera_controller, "Camera controller should be initialized")
        self.assertIsNotNone(self.system.zoom_processor, "Zoom processor should be initialized")
    
    def test_enhanced_system_process_image(self):
        """Test the enhanced system image processing."""
        # Initialize the system
        self.system.initialize()
        
        # Process the test image
        output_path = os.path.join(self.output_dir, 'output.jpg')
        detections, alerts, results = self.system.process_image(
            self.test_image,
            output_path=output_path,
            generate_alerts=True,
            zoom_on_detections=True
        )
        
        # Verify output
        self.assertTrue(os.path.exists(output_path), "Failed to save output image")
        
        # Verify results
        self.assertIsInstance(detections, list, "Detections should be a list")
        self.assertIsInstance(alerts, list, "Alerts should be a list")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        
        # Verify result keys
        self.assertIn('crops', results, "Results should contain 'crops'")
        self.assertIn('zooms', results, "Results should contain 'zooms'")
        self.assertIn('sequences', results, "Results should contain 'sequences'")
        self.assertIn('animations', results, "Results should contain 'animations'")
        self.assertIn('grids', results, "Results should contain 'grids'")
        
        # Verify some crops were created
        if len(results['crops']) > 0:
            for crop_path in results['crops']:
                self.assertTrue(os.path.exists(crop_path), f"Crop file does not exist: {crop_path}")
    
    def test_enhanced_system_scan_and_monitor(self):
        """Test the enhanced system scan and monitor functionality."""
        # Initialize the system
        self.system.initialize()
        
        # Scan and monitor the test image
        output_path = os.path.join(self.output_dir, 'scan_output.jpg')
        detections, alerts, results = self.system.scan_and_monitor(
            self.test_image,
            output_path=output_path,
            generate_alerts=True
        )
        
        # Verify output
        self.assertTrue(os.path.exists(output_path), "Failed to save output image")
        
        # Verify results
        self.assertIsInstance(detections, list, "Detections should be a list")
        self.assertIsInstance(alerts, list, "Alerts should be a list")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        
        # Verify result keys
        self.assertIn('crops', results, "Results should contain 'crops'")
        self.assertIn('zooms', results, "Results should contain 'zooms'")
        self.assertIn('sequences', results, "Results should contain 'sequences'")
        self.assertIn('animations', results, "Results should contain 'animations'")
        self.assertIn('grids', results, "Results should contain 'grids'")
        self.assertIn('scans', results, "Results should contain 'scans'")
        
        # Verify some scans were created
        if len(results['scans']) > 0:
            for scan_path in results['scans']:
                self.assertTrue(os.path.exists(scan_path), f"Scan file does not exist: {scan_path}")

if __name__ == '__main__':
    unittest.main()
