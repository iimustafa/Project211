"""
Test script for the stadium crowd monitoring system.
This script tests the functionality of the integrated system.
"""

import os
import sys
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from PIL import Image

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.data_utils import StadiumDataset
from src.system import StadiumMonitoringSystem

def test_on_synthetic_data(dataset_dir='stadium_dataset', num_samples=5):
    """
    Test the system on synthetic dataset samples.
    
    Args:
        dataset_dir: Directory containing the dataset
        num_samples: Number of samples to test
        
    Returns:
        test_results: Dictionary with test results
    """
    print(f"Testing system on {num_samples} samples from synthetic dataset...")
    
    # Load dataset
    dataset = StadiumDataset(dataset_dir)
    dataset.load_annotations()
    
    # Select random samples
    if len(dataset.image_ids) == 0:
        print(f"Error: No images found in {dataset_dir}")
        return None
        
    sample_ids = np.random.choice(dataset.image_ids, min(num_samples, len(dataset.image_ids)), replace=False)
    
    # Initialize system
    system = StadiumMonitoringSystem()
    system.initialize()
    
    # Create output directory
    os.makedirs('test_results', exist_ok=True)
    
    # Test on each sample
    test_results = {
        'total_samples': len(sample_ids),
        'total_detections': 0,
        'total_alerts': 0,
        'samples': []
    }
    
    for i, image_id in enumerate(sample_ids):
        # Get image path
        image_path = dataset.get_image_path(image_id)
        if not image_path:
            print(f"Error: Image path not found for ID {image_id}")
            continue
            
        # Get ground truth annotations
        gt_annotations = dataset.get_annotations_for_image(image_id)
        
        # Process image
        output_path = f"test_results/sample_{i+1}.png"
        detections, alerts = system.process_image(
            image_path,
            output_path=output_path,
            generate_alerts=True
        )
        
        # Count detections and alerts
        test_results['total_detections'] += len(detections)
        test_results['total_alerts'] += len(alerts)
        
        # Store sample results
        sample_result = {
            'image_id': int(image_id),
            'image_path': image_path,
            'output_path': output_path,
            'gt_annotations': len(gt_annotations),
            'detections': len(detections),
            'alerts': len(alerts),
            'alert_types': [alert['type'] for alert in alerts]
        }
        
        test_results['samples'].append(sample_result)
        
        print(f"Sample {i+1}/{len(sample_ids)}: {len(detections)} detections, {len(alerts)} alerts")
        
    # Generate summary
    print("\nTest Summary:")
    print(f"Total samples: {test_results['total_samples']}")
    print(f"Total detections: {test_results['total_detections']}")
    print(f"Total alerts: {test_results['total_alerts']}")
    print(f"Average detections per sample: {test_results['total_detections'] / test_results['total_samples']:.2f}")
    print(f"Average alerts per sample: {test_results['total_alerts'] / test_results['total_samples']:.2f}")
    
    # Save test results
    with open('test_results/summary.txt', 'w') as f:
        f.write("Stadium Crowd Monitoring System - Test Results\n")
        f.write("=" * 50 + "\n\n")
        f.write(f"Total samples: {test_results['total_samples']}\n")
        f.write(f"Total detections: {test_results['total_detections']}\n")
        f.write(f"Total alerts: {test_results['total_alerts']}\n")
        f.write(f"Average detections per sample: {test_results['total_detections'] / test_results['total_samples']:.2f}\n")
        f.write(f"Average alerts per sample: {test_results['total_alerts'] / test_results['total_samples']:.2f}\n\n")
        
        f.write("Sample Details:\n")
        for i, sample in enumerate(test_results['samples']):
            f.write(f"Sample {i+1}:\n")
            f.write(f"  Image ID: {sample['image_id']}\n")
            f.write(f"  Ground truth annotations: {sample['gt_annotations']}\n")
            f.write(f"  Detections: {sample['detections']}\n")
            f.write(f"  Alerts: {sample['alerts']}\n")
            if sample['alert_types']:
                f.write(f"  Alert types: {', '.join(sample['alert_types'])}\n")
            f.write("\n")
    
    return test_results

def evaluate_performance(test_results):
    """
    Evaluate system performance based on test results.
    
    Args:
        test_results: Dictionary with test results
        
    Returns:
        performance_metrics: Dictionary with performance metrics
    """
    if not test_results:
        return None
        
    # Calculate performance metrics
    performance_metrics = {
        'detection_rate': test_results['total_detections'] / sum(sample['gt_annotations'] for sample in test_results['samples']),
        'alert_rate': test_results['total_alerts'] / test_results['total_detections'] if test_results['total_detections'] > 0 else 0,
        'samples_with_alerts': sum(1 for sample in test_results['samples'] if sample['alerts'] > 0) / test_results['total_samples']
    }
    
    # Count alert types
    alert_types = {}
    for sample in test_results['samples']:
        for alert_type in sample['alert_types']:
            if alert_type in alert_types:
                alert_types[alert_type] += 1
            else:
                alert_types[alert_type] = 1
                
    performance_metrics['alert_types'] = alert_types
    
    # Print performance metrics
    print("\nPerformance Metrics:")
    print(f"Detection rate: {performance_metrics['detection_rate']:.2f}")
    print(f"Alert rate: {performance_metrics['alert_rate']:.2f}")
    print(f"Samples with alerts: {performance_metrics['samples_with_alerts']:.2f}")
    print("Alert types distribution:")
    for alert_type, count in alert_types.items():
        print(f"  - {alert_type}: {count}")
        
    # Save performance metrics
    with open('test_results/performance_metrics.txt', 'w') as f:
        f.write("Stadium Crowd Monitoring System - Performance Metrics\n")
        f.write("=" * 50 + "\n\n")
        f.write(f"Detection rate: {performance_metrics['detection_rate']:.2f}\n")
        f.write(f"Alert rate: {performance_metrics['alert_rate']:.2f}\n")
        f.write(f"Samples with alerts: {performance_metrics['samples_with_alerts']:.2f}\n\n")
        f.write("Alert types distribution:\n")
        for alert_type, count in alert_types.items():
            f.write(f"  - {alert_type}: {count}\n")
    
    # Visualize alert distribution
    if alert_types:
        plt.figure(figsize=(10, 6))
        plt.bar(alert_types.keys(), alert_types.values())
        plt.title('Alert Types Distribution')
        plt.xlabel('Alert Type')
        plt.ylabel('Count')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('test_results/alert_distribution.png')
    
    return performance_metrics

def main():
    """Main function to run tests."""
    # Test on synthetic data
    test_results = test_on_synthetic_data()
    
    # Evaluate performance
    if test_results:
        performance_metrics = evaluate_performance(test_results)
        
    print("\nTesting and evaluation complete. Results saved to 'test_results' directory.")

if __name__ == '__main__':
    main()
